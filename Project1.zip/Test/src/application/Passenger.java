package application;

public class Passenger implements Comparable<Passenger> {

	private int FlightNum;
	private int TicketNum;
	private String Name;
	private int PassNum;
	private String Nationality;
	private String DOB;

	public Passenger(int flightNum, int ticketNum, String name, int passNum, String nationality, String dOB) {
		super();
		this.FlightNum = flightNum;
		this.TicketNum = ticketNum;
		this.Name = name;
		this.PassNum = passNum;
		this.Nationality = nationality;
		this.DOB = dOB;
	}

	public Passenger() {
		super();
	}

	public int getFlightNum() {
		return this.FlightNum;
	}

	public void setFlightNum(int flightNum) {
		this.FlightNum = flightNum;
	}

	public int getTicketNum() {
		return this.TicketNum;
	}

	public void setTicketNum(int ticketNum) {
		this.TicketNum = ticketNum;
	}

	public String getName() {
		return this.Name;
	}

	public void setName(String name) {
		this.Name = name;
	}

	public int getPassNum() {
		return this.PassNum;
	}

	public void setPassNum(int passNum) {
		this.PassNum = passNum;
	}

	public String getNationality() {
		return this.Nationality;
	}

	public void setNationality(String nationality) {
		this.Nationality = nationality;
	}

	public String getDOB() {
		return this.DOB;
	}

	public void setDOB(String dOB) {
		this.DOB = dOB;
	}

	@Override
	public String toString() {
		return "Flight Number: " + FlightNum + ", Ticket Number: " + TicketNum + ", Name: " + Name + ", Passport Number: "
				+ PassNum + ", Nationality: " + Nationality + ", DOB: " + DOB;
	}

	@Override
	public int compareTo(Passenger o) {
		if (o.TicketNum == TicketNum) {
			return 0;
		} else if (o.TicketNum > TicketNum) {
			return 1;
		}
		return -1;
	}

}
