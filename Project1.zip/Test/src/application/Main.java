package application;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.paint.Paint;
import javafx.scene.text.Font;
import javafx.scene.text.Text;

public class Main extends Application {
	@Override
	public void start(Stage primaryStage) {
		try {

			StackPane root1 = new StackPane();
			Scene firstscene = new Scene(root1, 800, 800);
			root1.setStyle("-fx-background-color: LIGHTBLUE ");
			firstscene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(firstscene);
			Stage secStage = new Stage();
			StackPane root2 = new StackPane();
			secStage.setTitle("Information");
			Scene secscene = new Scene(root2, 900, 600);
			root2.setStyle("-fx-background-color: LIGHTBLUE ");
			secStage.setScene(secscene);
			secscene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			Stage triStage = new Stage();
			StackPane root3 = new StackPane();
			triStage.setTitle("Add or Edit A Flight");
			Scene triscene = new Scene(root3, 900, 600);
			root3.setStyle("-fx-background-color: LIGHTBLUE ");
			triStage.setScene(triscene);
			triscene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			Stage fourStage = new Stage();
			StackPane root4 = new StackPane();
			fourStage.setTitle("See Passengers");
			Scene fourscene = new Scene(root4, 900, 600);
			root4.setStyle("-fx-background-color: LIGHTBLUE ");
			fourStage.setScene(fourscene);
			fourscene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			Stage fifthStage = new Stage();
			StackPane root5 = new StackPane();
			fifthStage.setTitle("Book A Ticket");
			Scene fifthscene = new Scene(root5, 900, 600);
			root5.setStyle("-fx-background-color: LIGHTBLUE ");
			fifthStage.setScene(fifthscene);
			fifthscene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			Stage sixthStage = new Stage();
			StackPane root6 = new StackPane();
			sixthStage.setTitle("Cancel A Reservation");
			Scene sixthscene = new Scene(root6, 900, 600);
			root6.setStyle("-fx-background-color: LIGHTBLUE ");
			sixthStage.setScene(sixthscene);
			sixthscene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			Stage sevStage = new Stage();
			StackPane root7 = new StackPane();
			sevStage.setTitle("Check Ticket");
			Scene sevscene = new Scene(root7, 900, 600);
			root7.setStyle("-fx-background-color: LIGHTBLUE ");
			sevStage.setScene(sevscene);
			sevscene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			Stage eightStage = new Stage();
			StackPane root8 = new StackPane();
			eightStage.setTitle("Search Passenger");
			Scene eightscene = new Scene(root8, 900, 600);
			root8.setStyle("-fx-background-color: LIGHTBLUE ");
			eightStage.setScene(eightscene);
			eightscene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setTitle("Plane System");
			Text txt1 = new Text();
			txt1.setText("Welcome");
			txt1.setFill(Color.PURPLE);
			txt1.setFont(Font.font(50));
			txt1.setTranslateY(-340);
			Button btn1 = new Button("Display Menu");
			btn1.setTranslateX(-270);
			btn1.setTranslateY(-300);
			btn1.setTextFill(Paint.valueOf("white"));
			btn1.setScaleX(2);
			btn1.setStyle("-fx-background-color: Purple ");
			btn1.setFont(Font.font(16));
			Text menu = new Text();
			menu.setTranslateX(-250);
			menu.setTranslateY(100);
			menu.setFont(Font.font(20));
			Button btn2 = new Button("Exit");
			btn2.setTranslateX(270);
			btn2.setTranslateY(340);
			btn2.setStyle("-fx-background-color: black ");
			btn2.setTextFill(Paint.valueOf("White"));
			btn2.setScaleX(5);
			btn2.setFont(Font.font(16));
			Button show = new Button("Read");
			show.setTranslateY(-220);
			show.setTranslateX(-200);
			show.setStyle("-fx-background-color: purple ");
			show.setTextFill(Paint.valueOf("White"));
			show.setFont(Font.font(16));
			show.setScaleX(1.5);
			Button display = new Button("Display");
			display.setTranslateY(-140);
			display.setTranslateX(-40);
			display.setStyle("-fx-background-color: purple ");
			display.setTextFill(Paint.valueOf("White"));
			display.setFont(Font.font(16));
			display.setScaleX(1.5);
			Button spass = new Button("See Passengers");
			spass.setTranslateY(-60);
			spass.setTranslateX(-80);
			spass.setStyle("-fx-background-color: purple ");
			spass.setTextFill(Paint.valueOf("White"));
			spass.setFont(Font.font(16));
			spass.setScaleX(1.5);
			Button addedit = new Button("Add/Edit");
			addedit.setTranslateY(20);
			addedit.setTranslateX(-120);
			addedit.setStyle("-fx-background-color: purple ");
			addedit.setTextFill(Paint.valueOf("White"));
			addedit.setFont(Font.font(16));
			addedit.setScaleX(1.5);
			Button book = new Button("Book");
			book.setTranslateY(100);
			book.setTranslateX(-160);
			book.setStyle("-fx-background-color: purple ");
			book.setTextFill(Paint.valueOf("White"));
			book.setFont(Font.font(16));
			book.setScaleX(1.5);
			Button cancel = new Button("Cancel");
			cancel.setTranslateY(180);
			cancel.setTranslateX(-100);
			cancel.setStyle("-fx-background-color: purple ");
			cancel.setTextFill(Paint.valueOf("White"));
			cancel.setFont(Font.font(16));
			cancel.setScaleX(1.5);
			Button check = new Button("Check");
			check.setTranslateY(260);
			check.setTranslateX(-170);
			check.setStyle("-fx-background-color: purple ");
			check.setTextFill(Paint.valueOf("White"));
			check.setFont(Font.font(16));
			check.setScaleX(1.5);
			Button search = new Button("Search");
			search.setTranslateY(340);
			search.setTranslateX(-140);
			search.setStyle("-fx-background-color: purple ");
			search.setTextFill(Paint.valueOf("White"));
			search.setFont(Font.font(16));
			search.setScaleX(1.5);
			btn1.setOnAction(new EventHandler<ActionEvent>() {

				@Override
				public void handle(ActionEvent event) {
					menu.setText(
							"1-Read Info\n \n \n 2-Display Flight Information\n \n \n 3-See Passengers\n \n \n 4-Add/Edit Flight\n \n \n 5-Book A Ticket\n \n \n 6-Cancel A Reservation\n \n \n 7-Check Ticket\n \n \n 8-Search Passenger\n \n \n ");
					root1.getChildren().addAll(show, display, spass, addedit, book, cancel, check, search);
				}
			});
			btn2.setOnAction(new EventHandler<ActionEvent>() {

				@Override
				public void handle(ActionEvent event) {
					Platform.exit();

				}
			});
			LinkedList<Flight> Trips = new LinkedList<Flight>();
			LinkedList<Passenger> people = new LinkedList<Passenger>();
			show.setOnAction(new EventHandler<ActionEvent>() {

				@Override
				public void handle(ActionEvent event) {

					FileChooser fileChooser = new FileChooser();
					fileChooser.setTitle("Open Flight File");
					File file = fileChooser.showOpenDialog(primaryStage);
					if (file != null) {

						String filePath = file.getPath();
						try {
							BufferedReader reader = new BufferedReader(new FileReader(filePath));
							String line;

							while ((line = reader.readLine()) != null) {
								String[] arr = line.trim().split(",");
								Flight Trip = new Flight();
								Trip.setFlightNum(Integer.parseInt(arr[0]));
								Trip.setAirLineName(arr[1]);
								Trip.setFrom(arr[2]);
								Trip.setTo(arr[3]);
								Trip.setCapacity(Integer.parseInt(arr[4]));
								Trips.insertsorted(Trip);
							}

							reader.close();

						} catch (IOException ioe) {
							Alert alert = new Alert(AlertType.INFORMATION);
							alert.setTitle("ERORR!!!!");
							alert.setHeaderText("Alert!");
							alert.setContentText(ioe.getMessage());
						}
					}

					FileChooser fileChooser2 = new FileChooser();
					fileChooser2.setTitle("Open Passenger File");
					File file2 = fileChooser.showOpenDialog(primaryStage);
					if (file2 != null) {
						String filePath2 = file2.getPath();
						try {
							BufferedReader reader = new BufferedReader(new FileReader(filePath2));
							String line2;

							while ((line2 = reader.readLine()) != null) {
								String[] arr2 = line2.trim().split(",");
								Passenger newpass = new Passenger();
								newpass.setFlightNum(Integer.parseInt(arr2[0]));
								newpass.setTicketNum(Integer.parseInt(arr2[1]));
								newpass.setName(arr2[2]);
								newpass.setPassNum(Integer.parseInt(arr2[3]));
								newpass.setNationality(arr2[4]);
								newpass.setDOB(arr2[5]);
								Node<Flight> curr2 = Trips.head;
								while (curr2 != null) {
									if (curr2.data.getFlightNum() == newpass.getFlightNum()) {

										curr2.down = people.head;
										people.insertsorted(newpass);
									}
									curr2 = curr2.next;
								}
							}

							reader.close();

						} catch (IOException ioe) {
							Alert alert = new Alert(AlertType.INFORMATION);
							alert.setTitle("ERORR!!!!");
							alert.setHeaderText("Alert!");
							alert.setContentText(ioe.getMessage());
						}
					}

				}
			});
			display.setOnAction(new EventHandler<ActionEvent>() {

				@Override
				public void handle(ActionEvent event) {
					secStage.show();
					Text Flightsinfo = new Text();
					root2.getChildren().remove(Flightsinfo);
					Flightsinfo.setText(Trips.toString());
					Flightsinfo.setFill(Color.PURPLE);
					Flightsinfo.setFont(Font.font(16));
					Flightsinfo.setUnderline(true);
					root2.getChildren().add(Flightsinfo);

				}
			});
			Button add = new Button("ADD");
			add.setTranslateY(-250);
			add.setTranslateX(-340);
			add.setStyle("-fx-background-color: purple ");
			add.setTextFill(Paint.valueOf("White"));
			add.setFont(Font.font(16));
			add.setScaleX(1.5);
			Button edit = new Button("EDIT");
			edit.setTranslateY(-250);
			edit.setTranslateX(-240);
			edit.setStyle("-fx-background-color: purple ");
			edit.setTextFill(Paint.valueOf("White"));
			edit.setFont(Font.font(16));
			edit.setScaleX(1.5);
			addedit.setOnAction(new EventHandler<ActionEvent>() {

				@Override
				public void handle(ActionEvent event) {
					triStage.show();
					root3.getChildren().addAll(add, edit);
					Text information = new Text();
					information.setText("Flight Number: \n \n AirLine:\n \n From: \n\n To:\n \n Capacity:\n \n");
					information.setTranslateX(-300);
					information.setTranslateY(40);
					information.setFont(Font.font(26));
					information.setFill(Color.PURPLE);
					TextField flightnum = new TextField();
					flightnum.setTranslateX(-100);
					flightnum.setTranslateY(-130);
					flightnum.setMaxWidth(200);
					flightnum.setMaxHeight(30);
					TextField airline = new TextField();
					airline.setTranslateX(-180);
					airline.setTranslateY(-60);
					airline.setMaxWidth(200);
					airline.setMaxHeight(30);
					TextField from = new TextField();
					from.setTranslateX(-200);
					from.setTranslateY(10);
					from.setMaxWidth(200);
					from.setMaxHeight(30);
					TextField to = new TextField();
					to.setTranslateX(-230);
					to.setTranslateY(75);
					to.setMaxWidth(200);
					to.setMaxHeight(30);
					TextField capacity = new TextField();
					capacity.setTranslateX(-160);
					capacity.setTranslateY(145);
					capacity.setMaxWidth(200);
					capacity.setMaxHeight(30);
					Button save = new Button("Save");
					save.setTranslateY(220);
					save.setTranslateX(200);
					save.setStyle("-fx-background-color: purple ");
					save.setTextFill(Paint.valueOf("White"));
					save.setFont(Font.font(24));
					save.setScaleX(1.5);
					Text flinum = new Text("Insert Flight Number : ");
					flinum.setTranslateX(-250);
					flinum.setTranslateY(-200);
					flinum.setFont(Font.font(20));
					flinum.setFill(Color.PURPLE);
					TextField number = new TextField();
					number.setTranslateX(-70);
					number.setTranslateY(-200);
					number.setMaxWidth(150);
					number.setMaxHeight(30);
					Button searchfor = new Button("Search");
					searchfor.setTranslateY(-200);
					searchfor.setTranslateX(60);
					searchfor.setStyle("-fx-background-color: purple ");
					searchfor.setTextFill(Paint.valueOf("White"));
					searchfor.setFont(Font.font(12));
					searchfor.setScaleX(1.5);
					add.setOnAction(new EventHandler<ActionEvent>() {

						@Override
						public void handle(ActionEvent event) {
							root3.getChildren().addAll(information, flightnum, airline, from, to, capacity, save);
							root3.getChildren().removeAll(flinum);
							save.setOnAction(new EventHandler<ActionEvent>() {

								@Override
								public void handle(ActionEvent event) {
									Flight newflight = new Flight();
									newflight.setFlightNum(Integer.parseInt(flightnum.getText()));
									newflight.setAirLineName(airline.getText().trim());
									newflight.setFrom(from.getText().trim());
									newflight.setTo(to.getText().trim());
									newflight.setCapacity(Integer.parseInt(capacity.getText()));
									Trips.insertsorted(newflight);
									flightnum.setText("");
									airline.setText("");
									from.setText("");
									to.setText("");
									capacity.setText("");
									try {

										FileWriter writer = new FileWriter("Flights.txt");
										writer.append("\n" + newflight.getFlightNum() + "," + newflight.getAirLineName()
												+ "," + newflight.getFrom() + "," + newflight.getTo() + ","
												+ newflight.getCapacity() + "\n");
										writer.close();
									} catch (IOException ioe) {
										Alert alert = new Alert(AlertType.INFORMATION);
										alert.setTitle("!!!!");
										alert.setHeaderText("Alert");
										alert.setContentText(ioe.getMessage());
									}

								}
							});

						}
					});
					edit.setOnAction(new EventHandler<ActionEvent>() {

						@Override
						public void handle(ActionEvent event) {
							root3.getChildren().removeAll(information, flightnum, airline, from, to, capacity, save);
							root3.getChildren().addAll(flinum, number, searchfor);
							searchfor.setOnAction(new EventHandler<ActionEvent>() {

								@Override
								public void handle(ActionEvent event) {
									Button save2 = new Button("Save");
									save2.setTranslateY(220);
									save2.setTranslateX(200);
									save2.setStyle("-fx-background-color: purple ");
									save2.setTextFill(Paint.valueOf("White"));
									save2.setFont(Font.font(24));
									save2.setScaleX(1.5);
									Node<Flight> curr3 = Trips.head;
									while (curr3 != null) {
										if (curr3.data.getFlightNum() == Integer.parseInt(number.getText())) {
											root3.getChildren().removeAll(flinum, number, searchfor);
											root3.getChildren().addAll(information, flightnum, airline, from, to,
													capacity, save2);
											flightnum.setText(String.valueOf(curr3.data.getFlightNum()));
											airline.setText(curr3.data.getAirLineName());
											from.setText(curr3.data.getFrom());
											to.setText(curr3.data.getTo());
											capacity.setText(String.valueOf(curr3.data.getCapacity()));
											Node<Flight> cur = curr3;
											save2.setOnAction(new EventHandler<ActionEvent>() {

												@Override
												public void handle(ActionEvent event) {

													cur.data.setFlightNum(Integer.parseInt(flightnum.getText()));
													cur.data.setAirLineName(airline.getText().trim());
													cur.data.setFrom(from.getText().trim());
													cur.data.setTo(to.getText().trim());
													cur.data.setCapacity(Integer.parseInt(capacity.getText()));
													Trips.insertsorted(cur.data);
													flightnum.setText("");
													airline.setText("");
													from.setText("");
													to.setText("");
													capacity.setText("");
													try {

														FileWriter writer = new FileWriter("Flights.txt", true);
														writer.append(cur.data.getFlightNum() + ","
																+ cur.data.getAirLineName() + "," + cur.data.getFrom()
																+ "," + cur.data.getTo() + "," + cur.data.getCapacity()
																+ "\n");
														writer.close();
													} catch (IOException ioe) {
														Alert alert = new Alert(AlertType.INFORMATION);
														alert.setTitle("!!!!");
														alert.setHeaderText("Alert");
														alert.setContentText(ioe.getMessage());
													}

												}
											});

										}
										curr3 = curr3.next;
									}

								}
							});

						}
					});
				}
			});
			spass.setOnAction(new EventHandler<ActionEvent>() {

				@Override
				public void handle(ActionEvent event) {
					fourStage.show();
					Button searchflight = new Button("Search");
					searchflight.setTranslateY(-230);
					searchflight.setTranslateX(0);
					searchflight.setStyle("-fx-background-color: purple ");
					searchflight.setTextFill(Paint.valueOf("White"));
					searchflight.setFont(Font.font(12));
					searchflight.setScaleX(1.5);
					Text flinum2 = new Text("Insert Flight Number : ");
					flinum2.setTranslateX(-310);
					flinum2.setTranslateY(-230);
					flinum2.setFont(Font.font(20));
					flinum2.setFill(Color.PURPLE);
					TextField number2 = new TextField();
					number2.setTranslateX(-130);
					number2.setTranslateY(-230);
					number2.setMaxWidth(150);
					number2.setMaxHeight(30);
					root4.getChildren().addAll(searchflight, flinum2, number2);
					searchflight.setOnAction(new EventHandler<ActionEvent>() {

						@Override
						public void handle(ActionEvent event) {

							Node<Passenger> curr3 = people.head;
							Text passinfo = new Text();
							root4.getChildren().remove(passinfo);
							passinfo.setText(people.toString());
							passinfo.setFill(Color.PURPLE);
							passinfo.setFont(Font.font(12));
							passinfo.setUnderline(true);
							String line = new String();
							while (curr3 != null) {
								if (curr3.data.getFlightNum() == Integer.parseInt(number2.getText())) {
									root4.getChildren().remove(passinfo);
									line = line + curr3.toString() + "\n" + "\n";

								}
								curr3 = curr3.next;
							}
							passinfo.setText(line);
							root4.getChildren().add(passinfo);
						}
					});

				}
			});
			book.setOnAction(new EventHandler<ActionEvent>() {

				@Override
				public void handle(ActionEvent event) {
					fifthStage.show();
					Text informationpass = new Text();
					informationpass.setText(
							"Flight Number: \n \n Ticket Number:\n \n Name: \n\n Passport Number:\n \n Nationallity:\n \n DOF:");
					informationpass.setTranslateX(-300);
					informationpass.setTranslateY(0);
					informationpass.setFont(Font.font(26));
					informationpass.setFill(Color.PURPLE);
					TextField flightnump = new TextField();
					flightnump.setTranslateX(-130);
					flightnump.setTranslateY(-170);
					flightnump.setMaxWidth(200);
					flightnump.setMaxHeight(30);
					TextField ticket = new TextField();
					ticket.setTranslateX(-120);
					ticket.setTranslateY(-100);
					ticket.setMaxWidth(200);
					ticket.setMaxHeight(30);
					TextField name = new TextField();
					name.setTranslateX(-220);
					name.setTranslateY(-30);
					name.setMaxWidth(200);
					name.setMaxHeight(30);
					TextField passport = new TextField();
					passport.setTranslateX(-90);
					passport.setTranslateY(40);
					passport.setMaxWidth(200);
					passport.setMaxHeight(30);
					TextField nation = new TextField();
					nation.setTranslateX(-160);
					nation.setTranslateY(105);
					nation.setMaxWidth(200);
					nation.setMaxHeight(30);
					TextField birth = new TextField();
					birth.setTranslateX(-240);
					birth.setTranslateY(175);
					birth.setMaxWidth(200);
					birth.setMaxHeight(30);
					Button save3 = new Button("Save");
					save3.setTranslateY(240);
					save3.setTranslateX(200);
					save3.setStyle("-fx-background-color: purple ");
					save3.setTextFill(Paint.valueOf("White"));
					save3.setFont(Font.font(24));
					save3.setScaleX(1.5);
					root5.getChildren().addAll(informationpass, flightnump, ticket, name, passport, nation, birth,
							save3);

					save3.setOnAction(new EventHandler<ActionEvent>() {

						@Override
						public void handle(ActionEvent event) {
							Passenger passengernew = new Passenger();
							passengernew.setFlightNum(Integer.parseInt(flightnump.getText()));
							passengernew.setTicketNum(Integer.parseInt(ticket.getText()));
							passengernew.setName(name.getText().trim());
							passengernew.setPassNum(Integer.parseInt(passport.getText()));
							passengernew.setNationality(nation.getText().trim());
							passengernew.setDOB(birth.getText());
							people.insertsorted(passengernew);
							flightnump.setText("");
							ticket.setText("");
							name.setText("");
							passport.setText("");
							nation.setText("");
							birth.setText("");

							try {

								FileWriter writer3 = new FileWriter("passengers.txt");
								writer3.append("\n" + passengernew.getFlightNum() + "," + passengernew.getTicketNum()
										+ "," + passengernew.getName() + "," + passengernew.getPassNum() + ","
										+ passengernew.getNationality() + "," + passengernew.getDOB() + "\n");
								writer3.close();
							} catch (IOException ioe) {
								Alert alert = new Alert(AlertType.INFORMATION);
								alert.setTitle("!!!!");
								alert.setHeaderText("Alert");
								alert.setContentText(ioe.getMessage());
							}

						}
					});

				}
			});
			cancel.setOnAction(new EventHandler<ActionEvent>() {

				@Override
				public void handle(ActionEvent event) {
					sixthStage.show();
					Text ticknum = new Text("Insert Ticket Number : ");
					ticknum.setTranslateX(-150);
					ticknum.setTranslateY(-240);
					ticknum.setFont(Font.font(20));
					ticknum.setFill(Color.PURPLE);
					TextField numbertick = new TextField();
					numbertick.setTranslateX(30);
					numbertick.setTranslateY(-240);
					numbertick.setMaxWidth(150);
					numbertick.setMaxHeight(30);
					Button searchfortick = new Button("Search");
					searchfortick.setTranslateY(-240);
					searchfortick.setTranslateX(160);
					searchfortick.setStyle("-fx-background-color: purple ");
					searchfortick.setTextFill(Paint.valueOf("White"));
					searchfortick.setFont(Font.font(12));
					searchfortick.setScaleX(1.5);
					root6.getChildren().addAll(ticknum, numbertick, searchfortick);
					searchfortick.setOnAction(new EventHandler<ActionEvent>() {

						@Override
						public void handle(ActionEvent event) {
							Button cancel2 = new Button("CANCEL");
							cancel2.setTranslateY(220);
							cancel2.setTranslateX(200);
							cancel2.setStyle("-fx-background-color: purple ");
							cancel2.setTextFill(Paint.valueOf("White"));
							cancel2.setFont(Font.font(24));
							cancel2.setScaleX(1.5);
							Text informationpass2 = new Text();
							informationpass2.setText(
									"Flight Number: \n \n Ticket Number:\n \n Name: \n\n Passport Number:\n \n Nationallity:\n \n DOF:");
							informationpass2.setTranslateX(-300);
							informationpass2.setTranslateY(0);
							informationpass2.setFont(Font.font(26));
							informationpass2.setFill(Color.PURPLE);
							TextField flightnump2 = new TextField();
							flightnump2.setTranslateX(-130);
							flightnump2.setTranslateY(-170);
							flightnump2.setMaxWidth(200);
							flightnump2.setMaxHeight(30);
							TextField ticket2 = new TextField();
							ticket2.setTranslateX(-120);
							ticket2.setTranslateY(-100);
							ticket2.setMaxWidth(200);
							ticket2.setMaxHeight(30);
							TextField name2 = new TextField();
							name2.setTranslateX(-220);
							name2.setTranslateY(-30);
							name2.setMaxWidth(200);
							name2.setMaxHeight(30);
							TextField passport2 = new TextField();
							passport2.setTranslateX(-90);
							passport2.setTranslateY(40);
							passport2.setMaxWidth(200);
							passport2.setMaxHeight(30);
							TextField nation2 = new TextField();
							nation2.setTranslateX(-160);
							nation2.setTranslateY(105);
							nation2.setMaxWidth(200);
							nation2.setMaxHeight(30);
							TextField birth2 = new TextField();
							birth2.setTranslateX(-240);
							birth2.setTranslateY(175);
							birth2.setMaxWidth(200);
							birth2.setMaxHeight(30);

							root6.getChildren().addAll(informationpass2, flightnump2, ticket2, name2, passport2,
									nation2, birth2, cancel2);
							Node<Passenger> currpass = people.head;

							while (currpass != null) {
								if (currpass.data.getTicketNum() == Integer.parseInt(numbertick.getText())) {
									flightnump2.setText(String.valueOf(currpass.data.getFlightNum()));
									ticket2.setText(String.valueOf(currpass.data.getTicketNum()));
									name2.setText(currpass.data.getName());
									passport2.setText(String.valueOf(currpass.data.getPassNum()));
									nation2.setText(currpass.data.getNationality());
									birth2.setText(currpass.data.getDOB());

								}
								currpass = currpass.next;
							}
							Node<Passenger> cur2 = currpass;
							cancel2.setOnAction(new EventHandler<ActionEvent>() {

								@Override
								public void handle(ActionEvent event) {
									people.delete(cur2);

								}
							});

						}
					});

				}
			});
			check.setOnAction(new EventHandler<ActionEvent>() {

				@Override
				public void handle(ActionEvent event) {
					sevStage.show();
					Text ticknum2 = new Text("Insert Ticket Number : ");
					ticknum2.setTranslateX(-150);
					ticknum2.setTranslateY(-240);
					ticknum2.setFont(Font.font(20));
					ticknum2.setFill(Color.PURPLE);
					TextField numbertick2 = new TextField();
					numbertick2.setTranslateX(30);
					numbertick2.setTranslateY(-240);
					numbertick2.setMaxWidth(150);
					numbertick2.setMaxHeight(30);
					Button searchfortick2 = new Button("Search");
					searchfortick2.setTranslateY(-240);
					searchfortick2.setTranslateX(160);
					searchfortick2.setStyle("-fx-background-color: purple ");
					searchfortick2.setTextFill(Paint.valueOf("White"));
					searchfortick2.setFont(Font.font(12));
					searchfortick2.setScaleX(1.5);
					root7.getChildren().addAll(ticknum2, numbertick2, searchfortick2);
					searchfortick2.setOnAction(new EventHandler<ActionEvent>() {

						@Override
						public void handle(ActionEvent event) {
							Text informationpass3 = new Text();
							informationpass3.setText(
									"Flight Number: \n \n Ticket Number:\n \n Name: \n\n Passport Number:\n \n Nationallity:\n \n DOF:");
							informationpass3.setTranslateX(-300);
							informationpass3.setTranslateY(0);
							informationpass3.setFont(Font.font(26));
							informationpass3.setFill(Color.PURPLE);
							TextField flightnump3 = new TextField();
							flightnump3.setTranslateX(-130);
							flightnump3.setTranslateY(-170);
							flightnump3.setMaxWidth(200);
							flightnump3.setMaxHeight(30);
							TextField ticket3 = new TextField();
							ticket3.setTranslateX(-120);
							ticket3.setTranslateY(-100);
							ticket3.setMaxWidth(200);
							ticket3.setMaxHeight(30);
							TextField name3 = new TextField();
							name3.setTranslateX(-220);
							name3.setTranslateY(-30);
							name3.setMaxWidth(200);
							name3.setMaxHeight(30);
							TextField passport3 = new TextField();
							passport3.setTranslateX(-90);
							passport3.setTranslateY(40);
							passport3.setMaxWidth(200);
							passport3.setMaxHeight(30);
							TextField nation3 = new TextField();
							nation3.setTranslateX(-160);
							nation3.setTranslateY(105);
							nation3.setMaxWidth(200);
							nation3.setMaxHeight(30);
							TextField birth3 = new TextField();
							birth3.setTranslateX(-240);
							birth3.setTranslateY(175);
							birth3.setMaxWidth(200);
							birth3.setMaxHeight(30);

							root7.getChildren().addAll(informationpass3, flightnump3, ticket3, name3, passport3,
									nation3, birth3);
							Node<Passenger> currpass = people.head;

							while (currpass != null) {
								if (currpass.data.getTicketNum() == Integer.parseInt(numbertick2.getText())) {
									flightnump3.setText(String.valueOf(currpass.data.getFlightNum()));
									ticket3.setText(String.valueOf(currpass.data.getTicketNum()));
									name3.setText(currpass.data.getName());
									passport3.setText(String.valueOf(currpass.data.getPassNum()));
									nation3.setText(currpass.data.getNationality());
									birth3.setText(currpass.data.getDOB());

								}
								currpass = currpass.next;
							}

						}
					});

				}
			});
			search.setOnAction(new EventHandler<ActionEvent>() {

				@Override
				public void handle(ActionEvent event) {
					eightStage.show();
					Text ticknum2 = new Text("Insert Ticket Number : ");
					ticknum2.setTranslateX(-150);
					ticknum2.setTranslateY(-240);
					ticknum2.setFont(Font.font(20));
					ticknum2.setFill(Color.PURPLE);
					TextField numbertick2 = new TextField();
					numbertick2.setTranslateX(30);
					numbertick2.setTranslateY(-240);
					numbertick2.setMaxWidth(150);
					numbertick2.setMaxHeight(30);
					Button searchfortick2 = new Button("Search");
					searchfortick2.setTranslateY(-240);
					searchfortick2.setTranslateX(160);
					searchfortick2.setStyle("-fx-background-color: purple ");
					searchfortick2.setTextFill(Paint.valueOf("White"));
					searchfortick2.setFont(Font.font(12));
					searchfortick2.setScaleX(1.5);
					root8.getChildren().addAll(ticknum2, numbertick2, searchfortick2);
					searchfortick2.setOnAction(new EventHandler<ActionEvent>() {

						@Override
						public void handle(ActionEvent event) {
							Text informationpass3 = new Text();
							informationpass3.setText(
									"Flight Number: \n \n Ticket Number:\n \n Name: \n\n Passport Number:\n \n Nationallity:\n \n DOF:");
							informationpass3.setTranslateX(-300);
							informationpass3.setTranslateY(0);
							informationpass3.setFont(Font.font(26));
							informationpass3.setFill(Color.PURPLE);
							TextField flightnump3 = new TextField();
							flightnump3.setTranslateX(-130);
							flightnump3.setTranslateY(-170);
							flightnump3.setMaxWidth(200);
							flightnump3.setMaxHeight(30);
							TextField ticket3 = new TextField();
							ticket3.setTranslateX(-120);
							ticket3.setTranslateY(-100);
							ticket3.setMaxWidth(200);
							ticket3.setMaxHeight(30);
							TextField name3 = new TextField();
							name3.setTranslateX(-220);
							name3.setTranslateY(-30);
							name3.setMaxWidth(200);
							name3.setMaxHeight(30);
							TextField passport3 = new TextField();
							passport3.setTranslateX(-90);
							passport3.setTranslateY(40);
							passport3.setMaxWidth(200);
							passport3.setMaxHeight(30);
							TextField nation3 = new TextField();
							nation3.setTranslateX(-160);
							nation3.setTranslateY(105);
							nation3.setMaxWidth(200);
							nation3.setMaxHeight(30);
							TextField birth3 = new TextField();
							birth3.setTranslateX(-240);
							birth3.setTranslateY(175);
							birth3.setMaxWidth(200);
							birth3.setMaxHeight(30);

							root7.getChildren().addAll(informationpass3, flightnump3, ticket3, name3, passport3,
									nation3, birth3);
							Node<Passenger> currpass = people.head;

							while (currpass != null) {
								if (currpass.data.getTicketNum() == Integer.parseInt(numbertick2.getText())) {
									flightnump3.setText(String.valueOf(currpass.data.getFlightNum()));
									ticket3.setText(String.valueOf(currpass.data.getTicketNum()));
									name3.setText(currpass.data.getName());
									passport3.setText(String.valueOf(currpass.data.getPassNum()));
									nation3.setText(currpass.data.getNationality());
									birth3.setText(currpass.data.getDOB());

								}
								currpass = currpass.next;
							}

						}
					});

				}
			});
			root1.getChildren().addAll(btn1, txt1, menu, btn2);

			primaryStage.show();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public static void main(String[] args) {
		launch(args);
	}
};