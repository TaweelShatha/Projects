package application;

public class LinkedList<T extends Comparable<T>> {
	Node<T> head;

	public LinkedList() {
		super();
	}

	public LinkedList(Node<T> head) {
		super();
		this.head = head;
	}

	public Node<T> search(T data) {
		Node<T> curr = head;

		while ((curr != null) && (!curr.data.equals(data)))
			curr = curr.next;

		if (curr == null)
			System.out.println("Not found!");
		else
			return curr;
		return null;

	}

	public void insertAtHead(T data) {
		Node<T> newNode = new Node<>(data);
		if (head == null) {
			head = newNode;
		} else {
			newNode.setNext(head);
			head = newNode;
		}
	}

	public void insertAtEnd(T data) {
		Node<T> newNode = new Node<>(data);
		if (head == null) {
			head = newNode;
		} else {
			Node<T> last = head;
			while (last.getNext() != null)
				last = last.getNext();
			last.setNext(newNode);
		}
	}

	public void insertsorted(T data) {
		Node<T> newnode = new Node<T>(data);
		Node<T> prev = null, curr = head;
		for (; curr != null && curr.data.compareTo(data) < 0; prev = curr, curr = curr.next)
			;
		if (head == null) {
			head = newnode;
		} else if (curr == head) {
			newnode.next = head;
			head = newnode;
		} else if (curr == null) {
			newnode.next = curr;
			prev.next = newnode;
		} else {
			newnode.next = curr;
			prev.next = newnode;
		}

	}

	public void delete(Node<T> node) {
		Node<T> prev = null, curr = head;
		for (; curr != null && curr.data.compareTo(node.data) == 0; prev = curr, curr = curr.next)
			;
		if (head == null) {
			head = null;
		} else if (curr == head) {
			head.next = head.next.next;
		}
		else {
			prev.next = curr.next;
		}

	}

	public int length() {
		int length = 0;
		Node<T> curr = head;
		while (curr != null) {
			length++;
			curr = curr.getNext();
		}
		return length;
	}

	public String toString() {
		String res = "";
		Node<T> curr = this.head;
		while (curr != null) {
			res += curr + "\n";
			curr = curr.getNext();
		}
		return res;
	}

}
