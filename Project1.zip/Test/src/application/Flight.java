package application;

public class Flight implements Comparable<Flight> {
	private int FlightNum;
	private String AirLineName;
	private String From;
	private String To;
	private int Capacity;

	public Flight(int flightNum, String airLineName, String from, String to, int capacity) {
		super();
		this.FlightNum = flightNum;
		this.AirLineName = airLineName;
		this.From = from;
		this.To = to;
		this.Capacity = capacity;
	}

	public Flight() {
		super();
	}

	public int getFlightNum() {
		return this.FlightNum;
	}

	public void setFlightNum(int flightNum) {
		this.FlightNum = flightNum;
	}

	public String getAirLineName() {
		return this.AirLineName;
	}

	public void setAirLineName(String airLineName) {
		this.AirLineName = airLineName;
	}

	public String getFrom() {
		return this.From;
	}

	public void setFrom(String from) {
		this.From = from;
	}

	public String getTo() {
		return this.To;
	}

	public void setTo(String to) {
		this.To = to;
	}

	public int getCapacity() {
		return this.Capacity;
	}

	public void setCapacity(int capacity) {
		this.Capacity = capacity;
	}

	@Override
	public String toString() {
		return "Flight Number: " + FlightNum + ",   AirLine Name: " + AirLineName + ",   From: " + From + ",   To: " + To
				+ ",   Capacity: " + Capacity + "\n" ;
	}

	@Override
	public int compareTo(Flight o) {
		if (o.FlightNum == FlightNum) {
			return 0;
		} else if (o.FlightNum > FlightNum) {
			return 1;
		} else
			return -1;
	}

}
