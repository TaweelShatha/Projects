package application;

public class Node<T extends Comparable<T>> {

	T data;
	Node<T> next;
	Node<Passenger> down;
	

	public Node() {
		super();
	}

	public Node(T data) {

		this.data = data;
	}

	public T getData() {
		return data;
	}

	public Node<T> getNext() {
		return next;
	}

	public Node<Passenger> getDown() {
		return down;
	}

	public void setNext(Node<T> next) {
		this.next = next;
	}

	public void setPrev(Node<Passenger> down) {
		this.down = down;
	}

	public String toString() {
		return this.data.toString();
	}
}