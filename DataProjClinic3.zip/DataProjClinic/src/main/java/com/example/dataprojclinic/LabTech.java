package com.example.dataprojclinic;

public class LabTech extends Employee{

    String job = "Lab Technician";
    public LabTech(int staffId, String empName, int contactNum, String email, int IDNum) {
        super(staffId, empName, contactNum, email, IDNum);
        job = "Lab Technician";
    }
}
