package com.example.dataprojclinic;

public class Pharmacy {
    String mednum;
    String med_Desc;

    public Pharmacy(String mednum, String med_Desc) {
        this.mednum = mednum;
        this.med_Desc = med_Desc;
    }

    public String getMednum() {
        return mednum;
    }

    public void setMednum(String mednum) {
        this.mednum = mednum;
    }

    public String getMed_Desc() {
        return med_Desc;
    }

    public void setMed_Desc(String med_Desc) {
        this.med_Desc = med_Desc;
    }
}
