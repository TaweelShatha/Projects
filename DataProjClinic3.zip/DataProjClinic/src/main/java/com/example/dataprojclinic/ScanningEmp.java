package com.example.dataprojclinic;

public class ScanningEmp extends Employee{

   String  job = "Scanning Specialist";
    public ScanningEmp(int staffId, String empName, int contactNum, String email, int IDNum) {
        super(staffId, empName, contactNum, email, IDNum);
        job = "Scanning Specialist";
    }
}
