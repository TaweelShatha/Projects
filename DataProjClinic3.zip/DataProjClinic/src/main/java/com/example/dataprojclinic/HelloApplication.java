package com.example.dataprojclinic;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.beans.InvalidationListener;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.paint.Paint;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.scene.web.WebView;
import javafx.stage.Stage;
import javafx.util.converter.FormatStringConverter;
import javafx.util.converter.IntegerStringConverter;
import org.jetbrains.annotations.NotNull;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.*;

public class HelloApplication extends Application {
    static DBconection CON = new DBconection("127.0.0.1", "3306", "Clinic", "root", "1234");
    Connection mycon = CON.connectDB();
    ArrayList<Employee> data = new ArrayList<>();
    ObservableList<Employee> dataList = new ObservableList<Employee>() {
        @Override
        public void addListener(ListChangeListener<? super Employee> listChangeListener) {

        }

        @Override
        public void removeListener(ListChangeListener<? super Employee> listChangeListener) {

        }

        @Override
        public boolean addAll(Employee... employees) {
            return false;
        }

        @Override
        public boolean setAll(Employee... employees) {
            return false;
        }

        @Override
        public boolean setAll(Collection<? extends Employee> collection) {
            return false;
        }

        @Override
        public boolean removeAll(Employee... employees) {
            return false;
        }

        @Override
        public boolean retainAll(Employee... employees) {
            return false;
        }

        @Override
        public void remove(int i, int i1) {

        }

        @Override
        public int size() {
            return 0;
        }

        @Override
        public boolean isEmpty() {
            return false;
        }

        @Override
        public boolean contains(Object o) {
            return false;
        }

        @NotNull
        @Override
        public Iterator<Employee> iterator() {
            return null;
        }

        @NotNull
        @Override
        public Object[] toArray() {
            return new Object[0];
        }

        @NotNull
        @Override
        public <T> T[] toArray(@NotNull T[] a) {
            return null;
        }

        @Override
        public boolean add(Employee employee) {
            return false;
        }

        @Override
        public boolean remove(Object o) {
            return false;
        }

        @Override
        public boolean containsAll(@NotNull Collection<?> c) {
            return false;
        }

        @Override
        public boolean addAll(@NotNull Collection<? extends Employee> c) {
            return false;
        }

        @Override
        public boolean addAll(int index, @NotNull Collection<? extends Employee> c) {
            return false;
        }

        @Override
        public boolean removeAll(@NotNull Collection<?> c) {
            return false;
        }

        @Override
        public boolean retainAll(@NotNull Collection<?> c) {
            return false;
        }

        @Override
        public void clear() {

        }

        @Override
        public Employee get(int index) {
            return null;
        }

        @Override
        public Employee set(int index, Employee element) {
            return null;
        }

        @Override
        public void add(int index, Employee element) {

        }

        @Override
        public Employee remove(int index) {
            return null;
        }

        @Override
        public int indexOf(Object o) {
            return 0;
        }

        @Override
        public int lastIndexOf(Object o) {
            return 0;
        }

        @NotNull
        @Override
        public ListIterator<Employee> listIterator() {
            return null;
        }

        @NotNull
        @Override
        public ListIterator<Employee> listIterator(int index) {
            return null;
        }

        @NotNull
        @Override
        public List<Employee> subList(int fromIndex, int toIndex) {
            return null;
        }

        @Override
        public void addListener(InvalidationListener invalidationListener) {

        }

        @Override
        public void removeListener(InvalidationListener invalidationListener) {

        }
    };
    ArrayList<Tests> data2 = new ArrayList<>();
    ObservableList<Tests> dataList2 = new ObservableList<Tests>() {
        @Override
        public void addListener(ListChangeListener<? super Tests> listChangeListener) {

        }

        @Override
        public void removeListener(ListChangeListener<? super Tests> listChangeListener) {

        }

        @Override
        public boolean addAll(Tests... tests) {
            return false;
        }

        @Override
        public boolean setAll(Tests... tests) {
            return false;
        }

        @Override
        public boolean setAll(Collection<? extends Tests> collection) {
            return false;
        }

        @Override
        public boolean removeAll(Tests... tests) {
            return false;
        }

        @Override
        public boolean retainAll(Tests... tests) {
            return false;
        }

        @Override
        public void remove(int i, int i1) {

        }

        @Override
        public int size() {
            return 0;
        }

        @Override
        public boolean isEmpty() {
            return false;
        }

        @Override
        public boolean contains(Object o) {
            return false;
        }

        @NotNull
        @Override
        public Iterator<Tests> iterator() {
            return null;
        }

        @NotNull
        @Override
        public Object[] toArray() {
            return new Object[0];
        }

        @NotNull
        @Override
        public <T> T[] toArray(@NotNull T[] a) {
            return null;
        }

        @Override
        public boolean add(Tests tests) {
            return false;
        }

        @Override
        public boolean remove(Object o) {
            return false;
        }

        @Override
        public boolean containsAll(@NotNull Collection<?> c) {
            return false;
        }

        @Override
        public boolean addAll(@NotNull Collection<? extends Tests> c) {
            return false;
        }

        @Override
        public boolean addAll(int index, @NotNull Collection<? extends Tests> c) {
            return false;
        }

        @Override
        public boolean removeAll(@NotNull Collection<?> c) {
            return false;
        }

        @Override
        public boolean retainAll(@NotNull Collection<?> c) {
            return false;
        }

        @Override
        public void clear() {

        }

        @Override
        public Tests get(int index) {
            return null;
        }

        @Override
        public Tests set(int index, Tests element) {
            return null;
        }

        @Override
        public void add(int index, Tests element) {

        }

        @Override
        public Tests remove(int index) {
            return null;
        }

        @Override
        public int indexOf(Object o) {
            return 0;
        }

        @Override
        public int lastIndexOf(Object o) {
            return 0;
        }

        @NotNull
        @Override
        public ListIterator<Tests> listIterator() {
            return null;
        }

        @NotNull
        @Override
        public ListIterator<Tests> listIterator(int index) {
            return null;
        }

        @NotNull
        @Override
        public List<Tests> subList(int fromIndex, int toIndex) {
            return null;
        }

        @Override
        public void addListener(InvalidationListener invalidationListener) {

        }

        @Override
        public void removeListener(InvalidationListener invalidationListener) {

        }
    };
    ArrayList<Pharmacy> data3 = new ArrayList<>();
    ObservableList<Pharmacy> dataList3 = new ObservableList<Pharmacy>() {
        @Override
        public void addListener(ListChangeListener<? super Pharmacy> listChangeListener) {

        }

        @Override
        public void removeListener(ListChangeListener<? super Pharmacy> listChangeListener) {

        }

        @Override
        public boolean addAll(Pharmacy... pharmacies) {
            return false;
        }

        @Override
        public boolean setAll(Pharmacy... pharmacies) {
            return false;
        }

        @Override
        public boolean setAll(Collection<? extends Pharmacy> collection) {
            return false;
        }

        @Override
        public boolean removeAll(Pharmacy... pharmacies) {
            return false;
        }

        @Override
        public boolean retainAll(Pharmacy... pharmacies) {
            return false;
        }

        @Override
        public void remove(int i, int i1) {

        }

        @Override
        public int size() {
            return 0;
        }

        @Override
        public boolean isEmpty() {
            return false;
        }

        @Override
        public boolean contains(Object o) {
            return false;
        }

        @NotNull
        @Override
        public Iterator<Pharmacy> iterator() {
            return null;
        }

        @NotNull
        @Override
        public Object[] toArray() {
            return new Object[0];
        }

        @NotNull
        @Override
        public <T> T[] toArray(@NotNull T[] a) {
            return null;
        }

        @Override
        public boolean add(Pharmacy pharmacy) {
            return false;
        }

        @Override
        public boolean remove(Object o) {
            return false;
        }

        @Override
        public boolean containsAll(@NotNull Collection<?> c) {
            return false;
        }

        @Override
        public boolean addAll(@NotNull Collection<? extends Pharmacy> c) {
            return false;
        }

        @Override
        public boolean addAll(int index, @NotNull Collection<? extends Pharmacy> c) {
            return false;
        }

        @Override
        public boolean removeAll(@NotNull Collection<?> c) {
            return false;
        }

        @Override
        public boolean retainAll(@NotNull Collection<?> c) {
            return false;
        }

        @Override
        public void clear() {

        }

        @Override
        public Pharmacy get(int index) {
            return null;
        }

        @Override
        public Pharmacy set(int index, Pharmacy element) {
            return null;
        }

        @Override
        public void add(int index, Pharmacy element) {

        }

        @Override
        public Pharmacy remove(int index) {
            return null;
        }

        @Override
        public int indexOf(Object o) {
            return 0;
        }

        @Override
        public int lastIndexOf(Object o) {
            return 0;
        }

        @NotNull
        @Override
        public ListIterator<Pharmacy> listIterator() {
            return null;
        }

        @NotNull
        @Override
        public ListIterator<Pharmacy> listIterator(int index) {
            return null;
        }

        @NotNull
        @Override
        public List<Pharmacy> subList(int fromIndex, int toIndex) {
            return null;
        }

        @Override
        public void addListener(InvalidationListener invalidationListener) {

        }

        @Override
        public void removeListener(InvalidationListener invalidationListener) {

        }
    };
    ArrayList<Scan> data4 = new ArrayList<>();
    ObservableList<Scan> dataList4 = new ObservableList<Scan>() {
        @Override
        public void addListener(ListChangeListener<? super Scan> listChangeListener) {

        }

        @Override
        public void removeListener(ListChangeListener<? super Scan> listChangeListener) {

        }

        @Override
        public boolean addAll(Scan... scans) {
            return false;
        }

        @Override
        public boolean setAll(Scan... scans) {
            return false;
        }

        @Override
        public boolean setAll(Collection<? extends Scan> collection) {
            return false;
        }

        @Override
        public boolean removeAll(Scan... scans) {
            return false;
        }

        @Override
        public boolean retainAll(Scan... scans) {
            return false;
        }

        @Override
        public void remove(int i, int i1) {

        }

        @Override
        public int size() {
            return 0;
        }

        @Override
        public boolean isEmpty() {
            return false;
        }

        @Override
        public boolean contains(Object o) {
            return false;
        }

        @NotNull
        @Override
        public Iterator<Scan> iterator() {
            return null;
        }

        @NotNull
        @Override
        public Object[] toArray() {
            return new Object[0];
        }

        @NotNull
        @Override
        public <T> T[] toArray(@NotNull T[] a) {
            return null;
        }

        @Override
        public boolean add(Scan scan) {
            return false;
        }

        @Override
        public boolean remove(Object o) {
            return false;
        }

        @Override
        public boolean containsAll(@NotNull Collection<?> c) {
            return false;
        }

        @Override
        public boolean addAll(@NotNull Collection<? extends Scan> c) {
            return false;
        }

        @Override
        public boolean addAll(int index, @NotNull Collection<? extends Scan> c) {
            return false;
        }

        @Override
        public boolean removeAll(@NotNull Collection<?> c) {
            return false;
        }

        @Override
        public boolean retainAll(@NotNull Collection<?> c) {
            return false;
        }

        @Override
        public void clear() {

        }

        @Override
        public Scan get(int index) {
            return null;
        }

        @Override
        public Scan set(int index, Scan element) {
            return null;
        }

        @Override
        public void add(int index, Scan element) {

        }

        @Override
        public Scan remove(int index) {
            return null;
        }

        @Override
        public int indexOf(Object o) {
            return 0;
        }

        @Override
        public int lastIndexOf(Object o) {
            return 0;
        }

        @NotNull
        @Override
        public ListIterator<Scan> listIterator() {
            return null;
        }

        @NotNull
        @Override
        public ListIterator<Scan> listIterator(int index) {
            return null;
        }

        @NotNull
        @Override
        public List<Scan> subList(int fromIndex, int toIndex) {
            return null;
        }

        @Override
        public void addListener(InvalidationListener invalidationListener) {

        }

        @Override
        public void removeListener(InvalidationListener invalidationListener) {

        }
    };
    ArrayList<Appoinment> data5 = new ArrayList<>();
    ObservableList<Appoinment> dataList5 = new ObservableList<Appoinment>() {
        @Override
        public void addListener(ListChangeListener<? super Appoinment> listChangeListener) {

        }

        @Override
        public void removeListener(ListChangeListener<? super Appoinment> listChangeListener) {

        }

        @Override
        public boolean addAll(Appoinment... appoinments) {
            return false;
        }

        @Override
        public boolean setAll(Appoinment... appoinments) {
            return false;
        }

        @Override
        public boolean setAll(Collection<? extends Appoinment> collection) {
            return false;
        }

        @Override
        public boolean removeAll(Appoinment... appoinments) {
            return false;
        }

        @Override
        public boolean retainAll(Appoinment... appoinments) {
            return false;
        }

        @Override
        public void remove(int i, int i1) {

        }

        @Override
        public int size() {
            return 0;
        }

        @Override
        public boolean isEmpty() {
            return false;
        }

        @Override
        public boolean contains(Object o) {
            return false;
        }

        @NotNull
        @Override
        public Iterator<Appoinment> iterator() {
            return null;
        }

        @NotNull
        @Override
        public Object[] toArray() {
            return new Object[0];
        }

        @NotNull
        @Override
        public <T> T[] toArray(@NotNull T[] a) {
            return null;
        }

        @Override
        public boolean add(Appoinment appoinment) {
            return false;
        }

        @Override
        public boolean remove(Object o) {
            return false;
        }

        @Override
        public boolean containsAll(@NotNull Collection<?> c) {
            return false;
        }

        @Override
        public boolean addAll(@NotNull Collection<? extends Appoinment> c) {
            return false;
        }

        @Override
        public boolean addAll(int index, @NotNull Collection<? extends Appoinment> c) {
            return false;
        }

        @Override
        public boolean removeAll(@NotNull Collection<?> c) {
            return false;
        }

        @Override
        public boolean retainAll(@NotNull Collection<?> c) {
            return false;
        }

        @Override
        public void clear() {

        }

        @Override
        public Appoinment get(int index) {
            return null;
        }

        @Override
        public Appoinment set(int index, Appoinment element) {
            return null;
        }

        @Override
        public void add(int index, Appoinment element) {

        }

        @Override
        public Appoinment remove(int index) {
            return null;
        }

        @Override
        public int indexOf(Object o) {
            return 0;
        }

        @Override
        public int lastIndexOf(Object o) {
            return 0;
        }

        @NotNull
        @Override
        public ListIterator<Appoinment> listIterator() {
            return null;
        }

        @NotNull
        @Override
        public ListIterator<Appoinment> listIterator(int index) {
            return null;
        }

        @NotNull
        @Override
        public List<Appoinment> subList(int fromIndex, int toIndex) {
            return null;
        }

        @Override
        public void addListener(InvalidationListener invalidationListener) {

        }

        @Override
        public void removeListener(InvalidationListener invalidationListener) {

        }
    };
    ArrayList<Billing> data6 = new ArrayList<>();
    ObservableList dataList6 = new ObservableList() {
        @Override
        public void addListener(ListChangeListener listChangeListener) {

        }

        @Override
        public void removeListener(ListChangeListener listChangeListener) {

        }

        @Override
        public boolean addAll(Object[] objects) {
            return false;
        }

        @Override
        public boolean setAll(Object[] objects) {
            return false;
        }

        @Override
        public boolean setAll(Collection collection) {
            return false;
        }

        @Override
        public boolean removeAll(Object[] objects) {
            return false;
        }

        @Override
        public boolean retainAll(Object[] objects) {
            return false;
        }

        @Override
        public void remove(int i, int i1) {

        }

        @Override
        public int size() {
            return 0;
        }

        @Override
        public boolean isEmpty() {
            return false;
        }

        @Override
        public boolean contains(Object o) {
            return false;
        }

        @NotNull
        @Override
        public Iterator iterator() {
            return null;
        }

        @NotNull
        @Override
        public Object[] toArray() {
            return new Object[0];
        }

        @NotNull
        @Override
        public Object[] toArray(@NotNull Object[] a) {
            return new Object[0];
        }

        @Override
        public boolean add(Object o) {
            return false;
        }

        @Override
        public boolean remove(Object o) {
            return false;
        }

        @Override
        public boolean containsAll(@NotNull Collection c) {
            return false;
        }

        @Override
        public boolean addAll(@NotNull Collection c) {
            return false;
        }

        @Override
        public boolean addAll(int index, @NotNull Collection c) {
            return false;
        }

        @Override
        public boolean removeAll(@NotNull Collection c) {
            return false;
        }

        @Override
        public boolean retainAll(@NotNull Collection c) {
            return false;
        }

        @Override
        public void clear() {

        }

        @Override
        public Object get(int index) {
            return null;
        }

        @Override
        public Object set(int index, Object element) {
            return null;
        }

        @Override
        public void add(int index, Object element) {

        }

        @Override
        public Object remove(int index) {
            return null;
        }

        @Override
        public int indexOf(Object o) {
            return 0;
        }

        @Override
        public int lastIndexOf(Object o) {
            return 0;
        }

        @NotNull
        @Override
        public ListIterator listIterator() {
            return null;
        }

        @NotNull
        @Override
        public ListIterator listIterator(int index) {
            return null;
        }

        @NotNull
        @Override
        public List subList(int fromIndex, int toIndex) {
            return null;
        }

        @Override
        public void addListener(InvalidationListener invalidationListener) {

        }

        @Override
        public void removeListener(InvalidationListener invalidationListener) {

        }
    };

    public HelloApplication() throws SQLException, ClassNotFoundException {
    }

    public static void main(String[] args) throws SQLException, ClassNotFoundException {
        CON.connectDB();
        System.out.println("conection");
        launch();
    }

    @Override
    public void start(Stage stage) throws IOException {
        Receptionist sh = new Receptionist(4668, "Shatha Taweel", 595657431, "shathataweelz@outlook.com", 404126688);
        Pane root1 = new Pane();
        Scene scene = new Scene(root1, 1550, 750);
        stage.setTitle("Birziet Clinc System");
        root1.setStyle("-fx-background-color: purple");
        Image image = new Image(new FileInputStream("C:\\Users\\DELL\\Desktop\\data\\images.JPG"));
        ImageView imageView = new ImageView(image);
        imageView.setTranslateX(20);
        imageView.setFitWidth(1000);
        imageView.setPreserveRatio(true);
        Stage stage2 = new Stage();
        Pane root2 = new Pane();
        Scene scene2 = new Scene(root2, 1550, 750);
        stage2.setTitle("Birziet Clinc System");
        root2.setStyle("-fx-background-color: purple");
        Pane employees = new Pane();
        employees.setStyle("-fx-background-color: purple");
        Scene empp = new Scene(employees, 1550, 750);
        Pane labbb = new Pane();
        labbb.setStyle("-fx-background-color: purple");
        Scene labb = new Scene(labbb, 1550, 750);
        Pane pat = new Pane();
        pat.setStyle("-fx-background-color: purple");
        Scene patt = new Scene(pat, 1550, 750);
        Pane radiot = new Pane();
        radiot.setStyle("-fx-background-color: purple");
        Scene radioo = new Scene(radiot, 1550, 750);
        Pane bill = new Pane();
        bill.setStyle("-fx-background-color: purple");
        Scene biill = new Scene(bill, 1550, 750);
        Pane phar = new Pane();
        phar.setStyle("-fx-background-color: purple");
        Scene pharm = new Scene(phar, 1550, 750);
        Pane point = new Pane();
        point.setStyle("-fx-background-color: purple");
        Scene pointt = new Scene(point, 1550, 750);
        Text welcome = new Text();
        welcome.setText("Birzeit Clinic");
        welcome.setFont(Font.font("Forte", 90));
        welcome.setFill(Color.WHITE);
        welcome.setTranslateY(120);
        welcome.setTranslateX(1045);
        TextField user = new TextField();
        user.setPromptText("Username");
        user.setTranslateX(1200);
        user.setTranslateY(300);
        user.setAlignment(Pos.CENTER_LEFT);
        user.setFont(Font.font(16));
        PasswordField password = new PasswordField();
        password.setPromptText("Password");
        password.setTranslateX(1200);
        password.setTranslateY(350);
        password.setAlignment(Pos.CENTER_LEFT);
        password.setFont(Font.font(16));
        Button login = new Button("Login");
        login.setTranslateX(1255);
        login.setTranslateY(400);
        login.setFont(Font.font(18));
        login.setTextFill(Paint.valueOf("Lavender"));
        login.setBackground(Background.fill(Paint.valueOf("LightBlue")));
        login.setBorder(Border.stroke(Paint.valueOf("Lavender")));
        Button exit = new Button("Exit");
        exit.setTranslateX(1260);
        exit.setTranslateY(450);
        exit.setFont(Font.font(20));
        exit.setTextFill(Paint.valueOf("Lavender"));
        exit.setBackground(Background.fill(Paint.valueOf("LightBlue")));
        exit.setBorder(Border.stroke(Paint.valueOf("Lavender")));
        root1.getChildren().addAll(imageView, welcome, user, password, login, exit);
        VBox column1 = new VBox(0);
        column1.setTranslateY(-15);

        Button employee = new Button("Employees");
        employee.setBackground(new Background(new BackgroundFill(Color.LIGHTBLUE, new CornerRadii(0), Insets.EMPTY)));
        employee.setPrefSize(120, 120);
        Button lab = new Button("Laboratory");
        lab.setBackground(new Background(new BackgroundFill(Color.LIGHTBLUE, new CornerRadii(0), Insets.EMPTY)));
        lab.setPrefSize(120, 110);
        lab.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                lab.setOnAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event) {

                        try {

                            getDatalab();
                            dataList2 = FXCollections.observableArrayList(data2);


                        } catch (SQLException e) {
                            // TODO Auto-generated catch block
                            e.printStackTrace();
                        } catch (ClassNotFoundException e) {
                            // TODO Auto-generated catch block
                            e.printStackTrace();
                        }
                        TableView<Tests> tests = new TableView<Tests>();
                        Label label = new Label("Lab Tests");
                        label.setFont(new Font("Arial", 20));
                        label.setTextFill(Color.BLUE);
                        tests.setEditable(true);
                        tests.prefHeightProperty().bind(stage2.heightProperty().subtract(50));
                        tests.prefWidthProperty().bind(stage2.heightProperty().subtract(50));
                        tests.setTranslateX(800);
                        tests.setBorder(Border.stroke(Color.LIGHTBLUE));
                        tests.setEditable(true);
                        TableColumn<Tests, String> numcol = new TableColumn<Tests, String>("testnum");
                        numcol.setMinWidth(50);
                        numcol.setCellValueFactory(new PropertyValueFactory<Tests, String>("testnum"));
                        numcol.setCellFactory(TextFieldTableCell.forTableColumn());
                        numcol.setOnEditCommit((TableColumn.CellEditEvent<Tests, String> t) -> {
                            t.getTableView().getItems().get(t.getTablePosition().getRow()).setTestnum(t.getNewValue());
                        });
                        TableColumn<Tests, String> desc = new TableColumn<Tests, String>("test_desc");
                        desc.widthProperty().add(400);
                        desc.setCellValueFactory(new PropertyValueFactory<Tests, String>("test_desc"));
                        desc.setCellFactory(TextFieldTableCell.forTableColumn());
                        desc.setOnEditCommit((TableColumn.CellEditEvent<Tests, String> t) -> {
                            t.getTableView().getItems().get(t.getTablePosition().getRow()).setTest_desc(t.getNewValue());
                        });
                        tests.getColumns().addAll(numcol, desc);
                        tests.getItems().addAll(dataList2);
                        labbb.getChildren().addAll(tests);
                        stage2.setScene(labb);
                        stage2.show();
                    }
                });

            }
        });
        Button patients = new Button("Patients");
        patients.setBackground(new Background(new BackgroundFill(Color.LIGHTBLUE, new CornerRadii(0), Insets.EMPTY)));
        patients.setPrefSize(120, 110);
        patients.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                patients.setOnAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event) {
                        stage2.setScene(patt);
                        stage2.show();
                    }
                });

            }
        });
        Button radio = new Button("Radiology");
        radio.setBackground(new Background(new BackgroundFill(Color.LIGHTBLUE, new CornerRadii(0), Insets.EMPTY)));
        radio.setPrefSize(120, 110);
        radio.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                radio.setOnAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event) {
                        try {

                            getDatascans();
                            dataList4 = FXCollections.observableArrayList(data4);


                        } catch (SQLException e) {
                            // TODO Auto-generated catch block
                            e.printStackTrace();
                        } catch (ClassNotFoundException e) {
                            // TODO Auto-generated catch block
                            e.printStackTrace();
                        }
                        TableView<Scan> scans = new TableView<Scan>();
                        Label label = new Label("Scans");
                        label.setFont(new Font("Arial", 20));
                        label.setTextFill(Color.BLUE);
                        scans.setEditable(true);
                        scans.prefHeightProperty().bind(stage2.heightProperty().subtract(50));
                        scans.prefWidthProperty().bind(stage2.heightProperty().subtract(50));
                        scans.setTranslateX(800);
                        scans.setBorder(Border.stroke(Color.LIGHTBLUE));
                        scans.setEditable(true);
                        TableColumn<Scan, String> numscan = new TableColumn<Scan, String>("scannum");
                        numscan.setMinWidth(50);
                        numscan.setCellValueFactory(new PropertyValueFactory<Scan, String>("scannum"));
                        numscan.setCellFactory(TextFieldTableCell.forTableColumn());
                        numscan.setOnEditCommit((TableColumn.CellEditEvent<Scan, String> t) -> {
                            t.getTableView().getItems().get(t.getTablePosition().getRow()).setScannum(t.getNewValue());
                        });
                        TableColumn<Scan, String> desc3 = new TableColumn<Scan, String>("Scan_Desc");
                        desc3.widthProperty().add(400);
                        desc3.setCellValueFactory(new PropertyValueFactory<Scan, String>("Scan_Desc"));
                        desc3.setCellFactory(TextFieldTableCell.forTableColumn());
                        desc3.setOnEditCommit((TableColumn.CellEditEvent<Scan, String> t) -> {
                            t.getTableView().getItems().get(t.getTablePosition().getRow()).setScan_Desc(t.getNewValue());
                        });
                        scans.getColumns().addAll(numscan, desc3);
                        scans.getItems().addAll(dataList4);
                        radiot.getChildren().add(scans);
                        stage2.setScene(radioo);
                        stage2.show();
                    }
                });

            }
        });
        Button billing = new Button("Billing");
        billing.setBackground(new Background(new BackgroundFill(Color.LIGHTBLUE, new CornerRadii(0), Insets.EMPTY)));
        billing.setPrefSize(120, 110);
        billing.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                billing.setOnAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event) {
                        try {

                            getDatabill();
                            dataList6 = FXCollections.observableArrayList(data6);


                        } catch (SQLException e) {
                            // TODO Auto-generated catch block
                            e.printStackTrace();
                        } catch (ClassNotFoundException e) {
                            // TODO Auto-generated catch block
                            e.printStackTrace();
                        }
                        TableView<Billing> bills = new TableView<Billing>();
                        Label label = new Label("Bills");
                        label.setFont(new Font("Arial", 20));
                        label.setTextFill(Color.BLUE);
                        bills.setEditable(true);
                        bills.prefHeightProperty().bind(stage2.heightProperty().subtract(50));
                        bills.prefWidthProperty().bind(stage2.heightProperty().subtract(50));
                        bills.setTranslateX(800);
                        bills.setBorder(Border.stroke(Color.LIGHTBLUE));
                        bills.setEditable(true);
                        TableColumn<Billing, Integer> p_id = new TableColumn<Billing, Integer>("p_id");
                        p_id.setMinWidth(50);
                        p_id.setCellValueFactory(new PropertyValueFactory<Billing, Integer>("p_id"));
                        p_id.setCellFactory(TextFieldTableCell.forTableColumn(new IntegerStringConverter()));
                        p_id.setOnEditCommit((TableColumn.CellEditEvent<Billing, Integer> t) -> {
                            t.getTableView().getItems().get(t.getTablePosition().getRow()).setP_id(t.getNewValue());
                        });
                        TableColumn<Billing, Integer> cost = new TableColumn<Billing, Integer>("cost");
                        cost.widthProperty().add(400);
                        cost.setCellValueFactory(new PropertyValueFactory<Billing, Integer>("cost"));
                        cost.setCellFactory(TextFieldTableCell.forTableColumn(new IntegerStringConverter()));
                        cost.setOnEditCommit((TableColumn.CellEditEvent<Billing, Integer> t) -> {
                            t.getTableView().getItems().get(t.getTablePosition().getRow()).setCost(t.getNewValue());
                        });
                        bills.getColumns().addAll(p_id, cost);
                        bills.getItems().addAll(dataList6);
                        bill.getChildren().add(bills);
                        stage2.setScene(biill);
                        stage2.show();
                    }
                });

            }
        });
        Button pharmacy = new Button("Pharmacy");
        pharmacy.setBackground(new Background(new BackgroundFill(Color.LIGHTBLUE, new CornerRadii(0), Insets.EMPTY)));
        pharmacy.setPrefSize(120, 110);
        pharmacy.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                pharmacy.setOnAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event) {

                        try {

                            getDatapharm();
                            dataList3 = FXCollections.observableArrayList(data3);


                        } catch (SQLException e) {
                            // TODO Auto-generated catch block
                            e.printStackTrace();
                        } catch (ClassNotFoundException e) {
                            // TODO Auto-generated catch block
                            e.printStackTrace();
                        }
                        TableView<Pharmacy> pharmcy = new TableView<Pharmacy>();
                        Label label = new Label("Medicine");
                        label.setFont(new Font("Arial", 20));
                        label.setTextFill(Color.BLUE);
                        pharmcy.setEditable(true);
                        pharmcy.prefHeightProperty().bind(stage2.heightProperty().subtract(50));
                        pharmcy.prefWidthProperty().bind(stage2.heightProperty().subtract(50));
                        pharmcy.setTranslateX(800);
                        pharmcy.setBorder(Border.stroke(Color.LIGHTBLUE));
                        pharmcy.setEditable(true);
                        TableColumn<Pharmacy, String> numcol2 = new TableColumn<Pharmacy, String>("mednum");
                        numcol2.setMinWidth(50);
                        numcol2.setCellValueFactory(new PropertyValueFactory<Pharmacy, String>("mednum"));
                        numcol2.setCellFactory(TextFieldTableCell.forTableColumn());
                        numcol2.setOnEditCommit((TableColumn.CellEditEvent<Pharmacy, String> t) -> {
                            t.getTableView().getItems().get(t.getTablePosition().getRow()).setMednum(t.getNewValue());
                        });
                        TableColumn<Pharmacy, String> desc2 = new TableColumn<Pharmacy, String>("med_Desc");
                        desc2.widthProperty().add(400);
                        desc2.setCellValueFactory(new PropertyValueFactory<Pharmacy, String>("med_Desc"));
                        desc2.setCellFactory(TextFieldTableCell.forTableColumn());
                        desc2.setOnEditCommit((TableColumn.CellEditEvent<Pharmacy, String> t) -> {
                            t.getTableView().getItems().get(t.getTablePosition().getRow()).setMed_Desc(t.getNewValue());
                        });
                        pharmcy.getColumns().addAll(numcol2, desc2);
                        pharmcy.getItems().addAll(dataList3);
                        phar.getChildren().add(pharmcy);
                        stage2.setScene(pharm);
                        stage2.show();
                    }
                });

            }
        });
        Button app = new Button("Appointments");
        app.setBackground(new Background(new BackgroundFill(Color.LIGHTBLUE, new CornerRadii(0), Insets.EMPTY)));
        app.setPrefSize(120, 110);
        app.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                app.setOnAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event) {
                        try {

                            getDataapp();
                            dataList5 = FXCollections.observableArrayList(data5);


                        } catch (SQLException e) {
                            // TODO Auto-generated catch block
                            e.printStackTrace();
                        } catch (ClassNotFoundException e) {
                            // TODO Auto-generated catch block
                            e.printStackTrace();
                        }
                        TableView<Appoinment> apps = new TableView<Appoinment>();
                        Label label = new Label("Appointments");
                        label.setFont(new Font("Arial", 20));
                        label.setTextFill(Color.BLUE);
                        apps.setEditable(true);
                        apps.prefHeightProperty().bind(stage2.heightProperty().subtract(50));
                        apps.prefWidthProperty().bind(stage2.heightProperty().subtract(50));
                        apps.setTranslateX(800);
                        apps.setBorder(Border.stroke(Color.LIGHTBLUE));
                        apps.setEditable(true);
                        TableColumn<Appoinment, Integer> p_num = new TableColumn<Appoinment, Integer>("p_num");
                        p_num.setMinWidth(50);
                        p_num.setCellValueFactory(new PropertyValueFactory<Appoinment, Integer>("p_num"));
                        p_num.setCellFactory(TextFieldTableCell.forTableColumn(new IntegerStringConverter()));
                        p_num.setOnEditCommit((TableColumn.CellEditEvent<Appoinment, Integer> t) -> {
                            t.getTableView().getItems().get(t.getTablePosition().getRow()).setP_num(t.getNewValue());
                        });
                        TableColumn<Appoinment, String> adate = new TableColumn<Appoinment, String>("date");
                        adate.widthProperty().add(400);
                        adate.setCellValueFactory(new PropertyValueFactory<Appoinment, String>("date"));
                        adate.setCellFactory(TextFieldTableCell.forTableColumn());
                        adate.setOnEditCommit((TableColumn.CellEditEvent<Appoinment, String> t) -> {
                            t.getTableView().getItems().get(t.getTablePosition().getRow()).setDate(t.getNewValue());
                        });
                        apps.getColumns().addAll(p_num, adate);
                        apps.getItems().addAll(dataList5);
                        point.getChildren().add(apps);
                        stage2.setScene(pointt);
                        stage2.show();
                    }
                });

            }
        });
        column1.getChildren().addAll(employee, lab, patients, radio, billing, pharmacy, app);
        WebView webView = new WebView();
        webView.getEngine().load("https://www.worldometers.info/coronavirus/");
        webView.setPrefSize(750, 400);
        webView.setTranslateX(800);
        webView.setTranslateY(0);
        WebView webView2 = new WebView();
        webView2.getEngine().load("https://www.timeanddate.com/worldclock/fullscreen.html?n=702");
        webView2.setPrefSize(680, 160);
        webView2.setTranslateX(120);
        webView2.setTranslateY(0);
        Image image2 = new Image(new FileInputStream("C:\\Users\\DELL\\Desktop\\data\\note.png"));
        ImageView imageView2 = new ImageView(image2);
        imageView2.setTranslateX(180);
        imageView2.setTranslateY(160);
        imageView2.setFitWidth(550);
        imageView2.setPreserveRatio(true);
        Text announ = new Text();
        announ.setText("Announcements");
        announ.setFont(Font.font("Forte", 70));
        announ.setFill(Paint.valueOf("purple"));
        announ.setTranslateX(210);
        announ.setTranslateY(320);
        TableView text1 = new TableView<>();
        TableColumn<String, String> col1 = new TableColumn<>();
        text1.getColumns().addAll(col1);
        text1.setTranslateX(205);
        text1.setTranslateY(330);
        text1.prefHeightProperty().bind(image2.heightProperty().divide(4).add(20));
        text1.prefWidthProperty().bind(image2.widthProperty().divide(4).add(160));
        text1.setEditable(true);
        text1.setBackground(Background.fill(Paint.valueOf("LightBlue")));
        text1.setBorder(Border.stroke(Color.PURPLE));
        text1.setPlaceholder(new Label("No Announcements"));
        Rectangle rec = new Rectangle(700, 300);
        rec.setTranslateX(800);
        rec.setTranslateY(425);
        rec.setFill(Color.TRANSPARENT);
        rec.setStrokeWidth(7);
        rec.setStroke(Color.WHITE);
        Text name = new Text("Employee's Name: ");
        name.setFont(Font.font("Opera", 24));
        name.setTranslateX(1050);
        name.setTranslateY(510);
        name.setFill(Paint.valueOf("white"));
        Text Name = new Text(sh.getEmpName());
        Name.setFont(Font.font("Opera", 24));
        Name.setTranslateX(1300);
        Name.setTranslateY(510);
        Name.setFill(Paint.valueOf("LightBlue"));
        Text id = new Text("Employee's Id: ");
        id.setFont(Font.font("Opera", 24));
        id.setTranslateX(1050);
        id.setTranslateY(550);
        id.setFill(Paint.valueOf("white"));
        Text EmpIddd = new Text(String.valueOf(sh.getStaffId()));
        EmpIddd.setFont(Font.font("Opera", 24));
        EmpIddd.setTranslateX(1300);
        EmpIddd.setTranslateY(550);
        EmpIddd.setFill(Paint.valueOf("LightBlue"));
        Text email = new Text("E-Mail:  ");
        email.setFont(Font.font("Opera", 24));
        email.setTranslateX(1050);
        email.setTranslateY(590);
        email.setFill(Paint.valueOf("white"));
        Text Email = new Text(sh.getEmail());
        Email.setFont(Font.font("Opera", 24));
        Email.setTranslateX(1150);
        Email.setTranslateY(590);
        Email.setFill(Paint.valueOf("LightBlue"));
        Text idid = new Text("ID Number:  ");
        idid.setFont(Font.font("Opera", 24));
        idid.setTranslateX(1050);
        idid.setTranslateY(630);
        idid.setFill(Paint.valueOf("white"));
        Text idid2 = new Text(String.valueOf(sh.getIDNum()));
        idid2.setFont(Font.font("Opera", 24));
        idid2.setTranslateX(1200);
        idid2.setTranslateY(630);
        idid2.setFill(Paint.valueOf("LightBlue"));
        Text jobtitle = new Text("Job title:  ");
        jobtitle.setFont(Font.font("Opera", 24));
        jobtitle.setTranslateX(1050);
        jobtitle.setTranslateY(670);
        jobtitle.setFill(Paint.valueOf("white"));
        Text jobtitle2 = new Text(sh.job);
        jobtitle2.setFont(Font.font("Opera", 24));
        jobtitle2.setTranslateX(1180);
        jobtitle2.setTranslateY(670);
        jobtitle2.setFill(Paint.valueOf("LightBlue"));
        Image image3 = new Image(new FileInputStream("C:\\Users\\DELL\\Desktop\\data\\shatha.jpg"));
        ImageView imageView3 = new ImageView(image3);
        imageView3.setTranslateX(830);
        imageView3.setTranslateY(450);
        imageView3.setFitWidth(180);
        imageView3.setPreserveRatio(true);
        root2.getChildren().addAll(column1, webView, webView2, imageView2, announ, text1, rec, imageView3, Name, EmpIddd, name, id, email, Email, idid, idid2, jobtitle, jobtitle2);
        exit.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                exit.setOnAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event) {
                        Platform.exit();
                    }
                });

            }
        });
        login.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                login.setOnAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event) {
                        if (user.getText().equals(String.valueOf(sh.getStaffId())) && password.getText().equals("12345")) {
                            stage.setScene(scene2);
                        } else {
                            user.setText("INVALID");

                        }

                    }
                });

            }
        });
        employee.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                employee.setOnAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event) {
                        if (sh.job.equals("Receptionist (Administrator)")) {
                            try {

                                getData();
                                dataList = FXCollections.observableArrayList(data);


                            } catch (SQLException e) {
                                // TODO Auto-generated catch block
                                e.printStackTrace();
                            } catch (ClassNotFoundException e) {
                                // TODO Auto-generated catch block
                                e.printStackTrace();
                            }
                            TableView<Employee> myDataTable = new TableView<Employee>();
                            Label label = new Label("Employees");
                            label.setFont(new Font("Arial", 20));
                            label.setTextFill(Color.BLUE);
                            myDataTable.setEditable(true);
                            myDataTable.prefHeightProperty().bind(stage2.heightProperty().subtract(50));
                            myDataTable.prefWidthProperty().bind(stage2.heightProperty().subtract(50));
                            myDataTable.setTranslateX(800);
                            myDataTable.setBorder(Border.stroke(Color.LIGHTBLUE));
                            myDataTable.setEditable(true);
                            TableColumn<Employee, Integer> StaffidCol = new TableColumn<Employee, Integer>("StaffId");
                            StaffidCol.setMinWidth(50);
                            StaffidCol.setCellValueFactory(new PropertyValueFactory<Employee, Integer>("StaffId"));
                            StaffidCol.setCellFactory(TextFieldTableCell.forTableColumn(new IntegerStringConverter()));
                            StaffidCol.setOnEditCommit((TableColumn.CellEditEvent<Employee, Integer> t) -> {
                                t.getTableView().getItems().get(t.getTablePosition().getRow()).setStaffId(t.getNewValue());
                                updateID(t.getRowValue().getStaffId(), t.getNewValue());
                            });
                            TableColumn<Employee, String> nameCol = new TableColumn<Employee, String>("EmpName");
                            nameCol.setMinWidth(150);
                            nameCol.setCellValueFactory(new PropertyValueFactory<Employee, String>("EmpName"));
                            nameCol.setCellFactory(TextFieldTableCell.forTableColumn());
                            nameCol.setOnEditCommit((TableColumn.CellEditEvent<Employee, String> t) -> {
                                t.getTableView().getItems().get(t.getTablePosition().getRow()).setEmpName(t.getNewValue());
                                updateName(t.getRowValue().getStaffId(), t.getNewValue());
                            });


                            TableColumn<Employee, Integer> ConNumCol = new TableColumn<Employee, Integer>("ContactNum");
                            ConNumCol.setMinWidth(100);
                            ConNumCol.setCellValueFactory(new PropertyValueFactory<Employee, Integer>("ContactNum"));
                            ConNumCol.setCellFactory(TextFieldTableCell.forTableColumn(new IntegerStringConverter()));
                            ConNumCol.setOnEditCommit((TableColumn.CellEditEvent<Employee, Integer> t) -> {
                                t.getTableView().getItems().get(t.getTablePosition().getRow()).setContactNum(t.getNewValue());
                                updatecontact(t.getRowValue().getStaffId(), t.getNewValue());
                            });

                            TableColumn<Employee, String> EmailCol = new TableColumn<Employee, String>("Email");
                            EmailCol.setMinWidth(200);
                            EmailCol.setCellValueFactory(new PropertyValueFactory<Employee, String>("Email"));
                            EmailCol.setCellFactory(TextFieldTableCell.forTableColumn());
                            EmailCol.setOnEditCommit((TableColumn.CellEditEvent<Employee, String> t) -> {
                                t.getTableView().getItems().get(t.getTablePosition().getRow()).setEmail(t.getNewValue());
                                updateEmail(t.getRowValue().getStaffId(), t.getNewValue());
                            });
                            TableColumn<Employee, Integer> IdCol = new TableColumn<Employee, Integer>("IDNum");
                            IdCol.setMinWidth(100);
                            IdCol.setCellValueFactory(new PropertyValueFactory<Employee, Integer>("IDNum"));
                            IdCol.setCellFactory(TextFieldTableCell.forTableColumn(new IntegerStringConverter()));
                            IdCol.setOnEditCommit((TableColumn.CellEditEvent<Employee, Integer> t) -> {
                                t.getTableView().getItems().get(t.getTablePosition().getRow()).setIDNum(t.getNewValue());
                                updateId(t.getRowValue().getStaffId(), t.getNewValue());
                            });


                            myDataTable.getColumns().addAll(StaffidCol, nameCol, ConNumCol, EmailCol, IdCol);
                            final TextField addStaffId = new TextField();
                            addStaffId.setPromptText("Staff Num");
                            addStaffId.setMaxWidth(StaffidCol.getPrefWidth());

                            final TextField addName = new TextField();
                            addName.setMaxWidth(nameCol.getPrefWidth());
                            addName.setPromptText("Name");

                            final TextField addContact = new TextField();
                            addContact.setMaxWidth(ConNumCol.getPrefWidth());
                            addContact.setPromptText("Contact Number");

                            final TextField addEmail = new TextField();
                            addEmail.setMaxWidth(EmailCol.getPrefWidth());
                            addEmail.setPromptText("Email");

                            final TextField addId = new TextField();
                            addId.setMaxWidth(IdCol.getPrefWidth());
                            addId.setPromptText("Id Number");

                            final Button addButton = new Button("Add");
                            addButton.setMaxSize(100,200);
                            addButton.setOnAction((ActionEvent e) -> {
                                Employee rc=null;
                                rc = new Employee(
                                        Integer.valueOf(addStaffId.getText()),
                                        addName.getText(),
                                        Integer.valueOf(addContact.getText()),
                                        addEmail.getText(),
                                        Integer.valueOf(addId.getText()));
                                dataList.add(rc);
                                insertData(rc);
                                addStaffId.clear();
                                addName.clear();
                                addContact.clear();
                                addEmail.clear();
                                addId.clear();
                            });
                            final VBox hb = new VBox();
                            hb.setTranslateX(300);
                            hb.setTranslateY(100);
                            hb.getChildren().addAll(addStaffId, addName, addContact, addEmail, addId, addButton);
                            hb.setSpacing(6);
                            myDataTable.getItems().addAll(dataList);
                            employees.getChildren().addAll(myDataTable,hb);

                            stage2.setScene(empp);
                            stage2.show();
                        }
                    }
                });

            }
        });


        stage.setScene(scene);
        stage.show();
    }

    private void getDatalab() throws SQLException, ClassNotFoundException {
        // TODO Auto-generated method stub

        String SQL;

        CON.connectDB();
        System.out.println("Connection established");
        SQL = "select * from tests";
        Statement stmt = mycon.createStatement();
        ResultSet rs = stmt.executeQuery(SQL);

        while (rs.next()) {
            data2.add(new Tests(rs.getString(1), rs.getString(2)));
        }


    }

    private void getDatascans() throws SQLException, ClassNotFoundException {
        // TODO Auto-generated method stub

        String SQL;

        CON.connectDB();
        System.out.println("Connection established");
        SQL = "select * from scans";
        Statement stmt = mycon.createStatement();
        ResultSet rs = stmt.executeQuery(SQL);

        while (rs.next()) {
            data4.add(new Scan(rs.getString(1), rs.getString(2)));
        }


    }

    private void getDatabill() throws SQLException, ClassNotFoundException {
        // TODO Auto-generated method stub

        String SQL;

        CON.connectDB();
        System.out.println("Connection established");
        SQL = "select * from billing";
        Statement stmt = mycon.createStatement();
        ResultSet rs = stmt.executeQuery(SQL);

        while (rs.next()) {
            data6.add(new Billing(rs.getInt(1), rs.getInt(2)));
        }


    }

    private void getDatapharm() throws SQLException, ClassNotFoundException {
        // TODO Auto-generated method stub

        String SQL;

        CON.connectDB();
        System.out.println("Connection established");
        SQL = "select * from pharm";
        Statement stmt = mycon.createStatement();
        ResultSet rs = stmt.executeQuery(SQL);

        while (rs.next()) {
            data3.add(new Pharmacy(rs.getString(1), rs.getString(2)));
        }


    }

    private void getDataapp() throws SQLException, ClassNotFoundException {
        // TODO Auto-generated method stub

        String SQL;

        CON.connectDB();
        System.out.println("Connection established");
        SQL = "select * from app";
        Statement stmt = mycon.createStatement();
        ResultSet rs = stmt.executeQuery(SQL);

        while (rs.next()) {
            data5.add(new Appoinment(rs.getInt(1), rs.getString(2)));
        }


    }

    private void getData() throws SQLException, ClassNotFoundException {
        // TODO Auto-generated method stub

        String SQL;

        CON.connectDB();
        System.out.println("Connection established");
        SQL = "select * from Employee";
        Statement stmt = mycon.createStatement();
        ResultSet rs = stmt.executeQuery(SQL);

        while (rs.next()) {
            data.add(new Employee(rs.getInt(1), rs.getString(2), rs.getInt(3), rs.getString(4), rs.getInt(5)));
        }

    }

    public void updateID(int snum, int StaffId) {

        try {
            System.out.println("update  Employee set StaffId = " + StaffId + " where StaffId = " + snum);
            CON.connectDB();
            ExecuteStatement("update  employee set StaffId = " + StaffId + " where StaffId = " + snum + ";");
            System.out.println("Connection closed");

        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void updateName(int snum, String name) {

        try {
            System.out.println("update  Employee set emp_name = '" + name + "' where emp_name = " + snum);
            CON.connectDB();
            ExecuteStatement("update  Employee set Emp_Name = '" + name + "' where Emp_Name = " + snum + ";");
            System.out.println("Connection closed");

        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void updatecontact(int snum, int number) {

        try {
            System.out.println("update  Employee set con_num = '" + number + "' where con_num = " + snum);
            CON.connectDB();
            ExecuteStatement("update  Employee set con_num = '" + number + "' where con_num = " + snum + ";");
            System.out.println("Connection closed");

        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void updateEmail(int snum, String Email) {

        try {
            System.out.println("update  Employee set Email = '" + Email + "' where Email = " + snum);
            CON.connectDB();
            ExecuteStatement("update  Employee set Email = '" + Email + "' where Email = " + snum + ";");
            System.out.println("Connection closed");

        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void updateId(int snum, int Id) {

        try {
            System.out.println("update  Employee set Id_Num = " + Id + " where Id_Num = " + snum);
            CON.connectDB();
            ExecuteStatement("update  Employee set Id_Num = " + Id + " where Id_Num = " + snum + ";");
            System.out.println("Connection closed");

        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void ExecuteStatement(String SQL) throws SQLException {

        try {
            Statement stmt = CON.connectDB().createStatement();
            stmt.executeUpdate(SQL);
            stmt.close();


        } catch (SQLException s) {
            s.printStackTrace();
            System.out.println("SQL statement is not executed!");

        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }


    }

    private void insertData(Employee rc) {

        try {
            System.out.println("Insert into employee (snum, sname,major, age, level) values(" + rc.getStaffId() + ",'" + rc.getEmpName() + "','" + rc.getContactNum() + "'," + rc.getEmail() + ", '" + rc.getIDNum() + "')");

            CON.connectDB();
            ExecuteStatement("Insert into employee (staffid, empname,contactnum, email, idnum) values(" + rc.getStaffId() + ",'" + rc.getEmpName() + "','" + rc.getContactNum() + "'," + rc.getEmail() + ", '" + rc.getIDNum() + "');");
            System.out.println("Connection closed");

        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}