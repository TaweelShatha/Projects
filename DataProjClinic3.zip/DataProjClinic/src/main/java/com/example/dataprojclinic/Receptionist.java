package com.example.dataprojclinic;

public class Receptionist extends Employee{
    String job = "Receptionist (Administrator)";
    public Receptionist(int staffId, String empName, int contactNum, String email, int IDNum) {
        super(staffId, empName, contactNum, email, IDNum);
        job = "Receptionist (Administrator)";
    }
}
