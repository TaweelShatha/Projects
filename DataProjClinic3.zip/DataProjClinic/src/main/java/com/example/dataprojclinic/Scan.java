package com.example.dataprojclinic;

public class Scan {
    String scannum;
    String Scan_Desc;

    public Scan(String scannum, String scan_Desc) {
        this.scannum = scannum;
        Scan_Desc = scan_Desc;
    }

    public String getScannum() {
        return scannum;
    }

    public void setScannum(String scannum) {
        this.scannum = scannum;
    }

    public String getScan_Desc() {
        return Scan_Desc;
    }

    public void setScan_Desc(String scan_Desc) {
        Scan_Desc = scan_Desc;
    }
}
