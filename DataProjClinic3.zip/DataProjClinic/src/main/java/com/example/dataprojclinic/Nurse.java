package com.example.dataprojclinic;

public class Nurse extends Employee {
    String job = "Nurse";

    public Nurse(int staffId, String empName, int contactNum, String email, int IDNum) {
        super(staffId, empName, contactNum, email, IDNum);
        job = "Nurse";
    }

}
