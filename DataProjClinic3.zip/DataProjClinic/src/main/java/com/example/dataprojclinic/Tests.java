package com.example.dataprojclinic;

public class Tests {
    String testnum;
    String test_desc;

    public Tests(String testnum, String test_desc) {
        this.testnum = testnum;
        this.test_desc = test_desc;
    }

    public String getTestnum() {
        return testnum;
    }

    public void setTestnum(String testnum) {
        this.testnum = testnum;
    }

    public String getTest_desc() {
        return test_desc;
    }

    public void setTest_desc(String test_desc) {
        this.test_desc = test_desc;
    }
}
