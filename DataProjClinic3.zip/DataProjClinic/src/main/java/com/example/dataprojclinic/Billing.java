package com.example.dataprojclinic;

public class Billing {
    int p_id;
    int cost;

    public Billing(int p_id, int cost) {
        this.p_id = p_id;

        this.cost = cost;
    }

    public int getP_id() {
        return p_id;
    }

    public void setP_id(int p_id) {
        this.p_id = p_id;
    }


    public int getCost() {
        return cost;
    }

    public void setCost(int cost) {
        this.cost = cost;
    }
}
