package com.example.dataprojclinic;

public class Doctor extends Employee{

    String job = "Doctor";
    public Doctor(int staffId, String empName, int contactNum, String email, int IDNum) {
        super(staffId, empName, contactNum, email, IDNum);
        job = "Doctor";
    }
}
