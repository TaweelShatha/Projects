package com.example.dataprojclinic;

public class Patient {
    String name, phone, status;
    int insurance;
    String job, DOB, gender;
    int id_num;
    String E_name, E_relation, E_phone, scan, labtest, pharmacy, ENT, temp, BP, heartbeat, Med;


    public Patient(String name, String phone, String status, int insurance, String job, String DOB, String gender, int id_num, String e_name, String e_relation, String e_phone) {
        this.name = name;
        this.phone = phone;
        this.status = status;
        this.insurance = insurance;
        this.job = job;
        this.DOB = DOB;
        this.gender = gender;
        this.id_num = id_num;
        this.E_name = e_name;
        this.E_relation = e_relation;
        this.E_phone = e_phone;
        scan = null;
        labtest = null;
        pharmacy = null;
        ENT = null;
        temp = null;
        BP = null;
        heartbeat = null;
        Med = null;
    }


    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return this.phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getStatus() {
        return this.status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public int getInsurance() {
        return this.insurance;
    }

    public void setInsurance(int insurance) {
        this.insurance = insurance;
    }

    public String getJob() {
        return this.job;
    }

    public void setJob(String job) {
        this.job = job;
    }

    public String getDOB() {
        return this.DOB;
    }

    public void setDOB(String DOB) {
        this.DOB = DOB;
    }

    public String getGender() {
        return this.gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public int getId_num() {
        return this.id_num;
    }

    public void setId_num(int id_num) {
        this.id_num = id_num;
    }

    public String getMed() {
        return Med;
    }

    public void setMed(String med) {
        Med = med;
    }

    public String getE_name() {
        return this.E_name;
    }

    public void setE_name(String e_name) {
        this.E_name = e_name;
    }

    public String getE_relation() {
        return this.E_relation;
    }

    public void setE_relation(String e_relation) {
        this.E_relation = e_relation;
    }

    public String getE_phone() {
        return this.E_phone;
    }

    public void setE_phone(String e_phone) {
        this.E_phone = e_phone;
    }

    public String getScan() {
        return this.scan;
    }

    public void setScan(String scan) {
        this.scan = scan;
    }

    public String getLabtest() {
        return this.labtest;
    }

    public void setLabtest(String labtest) {
        this.labtest = labtest;
    }

    public String getPharmacy() {
        return this.pharmacy;
    }

    public void setPharmacy(String pharmacy) {
        this.pharmacy = pharmacy;
    }

    public String getENT() {
        return this.ENT;
    }

    public void setENT(String ENT) {
        this.ENT = ENT;
    }

    public String getTemp() {
        return this.temp;
    }

    public void setTemp(String temp) {
        this.temp = temp;
    }

    public String getBP() {
        return this.BP;
    }

    public void setBP(String BP) {
        this.BP = BP;
    }

    public String getHeartbeat() {
        return this.heartbeat;
    }

    public void setHeartbeat(String heartbeat) {
        this.heartbeat = heartbeat;
    }
}

