package com.example.dataprojclinic;

public class Appoinment {
    int p_num;
    String date;


    public Appoinment(int p_num,String date ) {
        this.date = date;
        this.p_num = p_num;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }


    public int getP_num() {
        return p_num;
    }

    public void setP_num(int p_num) {
        this.p_num = p_num;
    }
}
