package com.example.dataprojclinic;

public class Employee {
    int StaffId;
    String EmpName;
    int ContactNum;
    String Email;
    int IDNum;

    public Employee() {

    }

    public Employee(int staffId, String empName, int contactNum, String email, int IDNum) {
        this.StaffId = staffId;
        this.EmpName = empName;
        this.ContactNum = contactNum;
        this.Email = email;
        this.IDNum = IDNum;
    }
    public int getStaffId() {
        return this.StaffId;
    }

    public void setStaffId(int staffId) {
        this.StaffId = staffId;
    }

    public String getEmpName() {
        return this.EmpName;
    }

    public void setEmpName(String empName) {
        this.EmpName = empName;
    }

    public int getContactNum() {
        return this.ContactNum;
    }

    public void setContactNum(int contactNum) {
        this.ContactNum = contactNum;
    }

    public String getEmail() {
        return this.Email;
    }

    public void setEmail(String email) {
        this.Email = email;
    }

    public int getIDNum() {
        return this.IDNum;
    }

    public void setIDNum(int IDNum) {
        this.IDNum = IDNum;
    }

    public  void setRecords(String sg, int i) {

        switch  (i) {

            case 1:
                StaffId = Integer.parseInt(sg);
                break;
            case 2:
                EmpName = sg;
                break;
            case 3:
                ContactNum = Integer.parseInt(sg);
                break;
            case 4:
                Email = sg;
                break;
            case 5:
                IDNum = Integer.parseInt(sg);

        }
    }

    public String getField(int i) {

        String res = null;
        switch(i) {
            case 1:
                res = String.valueOf(StaffId);
                break;
            case 2:
                res = EmpName;
                break;
            case 3:
                res = String.valueOf(ContactNum);
                break;
            case 4:
                res = Email;
                break;
            case 5:
                res = String.valueOf(IDNum);


        }
        return res;
    }


}
