package com.example.project3;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.Border;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import org.kordamp.ikonli.javafx.Icon;

import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class HelloApplication extends Application {
    public static void main(String[] args) {
        launch();


    }

    @Override
    public void start(Stage stage) throws IOException {
        Pane root1 = new Pane();
        Pane root2 = new Pane();
        Pane root3 = new Pane();
        Pane root4 = new Pane();
        Pane root5 = new Pane();
        Scene scene = new Scene(root1, 1200, 800);
        Scene scene2 = new Scene(root2, 1200, 800);
        Scene scene3 = new Scene(root3, 1200, 800);
        Scene scene4 = new Scene(root4, 400, 400);
        Scene scene5 = new Scene(root5, 800, 400);
        Stage insertstage = new Stage();
        Stage delstage = new Stage();
        stage.setTitle("Birzeit University");
        root1.setBackground(Background.fill(Color.GREEN));
        root2.setBackground(Background.fill(Color.GREEN));
        root3.setBackground(Background.fill(Color.GREEN));
        root4.setBackground(Background.fill(Color.GREEN));
        root5.setBackground(Background.fill(Color.GREEN));
        Image logo = new Image(new FileInputStream("C:\\Users\\thinkpad\\Desktop\\ProjectData\\Birzeit_University.png"));
        ImageView imageView = new ImageView(logo);
        Image backpic = new Image(new FileInputStream("C:\\Users\\thinkpad\\Desktop\\ProjectData\\back.png"));
        ImageView backview = new ImageView(backpic);
        backview.setFitHeight(25);
        backview.setFitWidth(25);
        imageView.setFitHeight(scene.getHeight() / 2);
        imageView.setFitWidth(scene.getWidth() / 2);
        imageView.setTranslateX(300);
        imageView.setTranslateY(70);
        Rectangle rec = new Rectangle(scene.getWidth(), 400);
        rec.setFill(Color.WHITE);
        rec.setTranslateY(70);
        Button dep = new Button("DEPARTMENTS");
        dep.setFont(Font.font("Forte", 50));
        dep.setBackground(Background.fill(Color.WHITE));
        dep.setTextFill(Color.GREEN);
        dep.setBorder(Border.stroke(Color.BLACK));
        dep.setTranslateX(100);
        dep.setTranslateY(600);
        Button student = new Button("STUDENTS");
        student.setFont(Font.font("Forte", 50));
        student.setBackground(Background.fill(Color.WHITE));
        student.setTextFill(Color.GREEN);
        student.setBorder(Border.stroke(Color.BLACK));
        student.setScaleX(1.3);
        student.setScaleY(0.9755);
        student.setTranslateX(725);
        student.setTranslateY(600);
        AVL<Department> deps = new AVL<>();

        Button search = new Button("SEARCH");
        search.setFont(Font.font("Forte", 30));
        search.setBackground(Background.fill(Color.WHITE));
        search.setTextFill(Color.GREEN);
        search.setBorder(Border.stroke(Color.BLACK));
        search.setTranslateX(50);
        search.setTranslateY(20);
        TextField name = new TextField();
        name.setTranslateX(250);
        name.setTranslateY(35);
        Button search2 = new Button("Find");
        search2.setFont(Font.font("Forte", 18));
        search2.setBackground(Background.fill(Color.WHITE));
        search2.setTextFill(Color.GREEN);
        search2.setBorder(Border.stroke(Color.BLACK));
        search2.setTranslateX(420);
        search2.setTranslateY(30);
        Button insert = new Button("INSERT");
        insert.setFont(Font.font("Forte", 30));
        insert.setBackground(Background.fill(Color.WHITE));
        insert.setTextFill(Color.GREEN);
        insert.setBorder(Border.stroke(Color.BLACK));
        insert.setTranslateX(50);
        insert.setTranslateY(100);
        Button Delete = new Button("DELETE");
        Delete.setFont(Font.font("Forte", 30));
        Delete.setBackground(Background.fill(Color.WHITE));
        Delete.setTextFill(Color.GREEN);
        Delete.setBorder(Border.stroke(Color.BLACK));
        Delete.setTranslateX(50);
        Delete.setTranslateY(175);
        Button height = new Button("HEIGHT");
        height.setFont(Font.font("Forte", 30));
        height.setBackground(Background.fill(Color.WHITE));
        height.setTextFill(Color.GREEN);
        height.setBorder(Border.stroke(Color.BLACK));
        height.setTranslateX(50);
        height.setTranslateY(250);
        TextArea hit = new TextArea();
        hit.setTranslateX(250);
        hit.setTranslateY(250);
        hit.setBorder(Border.stroke(Color.BLACK));
        hit.setEditable(false);
        hit.setMaxSize(100, 50);
        TextField namedel = new TextField();
        namedel.setTranslateX(250);
        namedel.setTranslateY(180);
        Button del = new Button("Remove");
        del.setFont(Font.font("Forte", 18));
        del.setBackground(Background.fill(Color.WHITE));
        del.setTextFill(Color.GREEN);
        del.setBorder(Border.stroke(Color.BLACK));
        del.setTranslateX(420);
        del.setTranslateY(175);
        TextArea result = new TextArea();
        result.setTranslateX(500);
        result.setTranslateY(30);
        result.setBorder(Border.stroke(Color.BLACK));
        result.setEditable(false);
        result.setFont(Font.font(20));
        result.setMaxSize(300, 100);
        Text insertname = new Text("Insert Name:");
        insertname.setTranslateX(250);
        insertname.setTranslateY(125);
        insertname.setFill(Color.WHITE);
        insertname.setFont(Font.font("Forte", 30));
        TextField inname = new TextField();
        inname.setTranslateX(450);
        inname.setTranslateY(100);
        Text insertfile = new Text("Related File:");
        insertfile.setTranslateX(250);
        insertfile.setTranslateY(175);
        insertfile.setFill(Color.WHITE);
        insertfile.setFont(Font.font("Forte", 30));
        TextField infile = new TextField();
        infile.setTranslateX(450);
        infile.setTranslateY(150);
        Button save = new Button("Save");
        save.setFont(Font.font("Forte", 18));
        save.setBackground(Background.fill(Color.WHITE));
        save.setTextFill(Color.GREEN);
        save.setBorder(Border.stroke(Color.BLACK));
        save.setTranslateX(375);
        save.setTranslateY(200);
        Text depart = new Text();
        depart.setFont(Font.font("Bold", 15));
        depart.setFill(Color.WHITE);
        depart.setTranslateX(900);
        depart.setTranslateY(20);
        HBox hb = new HBox();
        Text enter = new Text("Enter Department  name: ");
        enter.setFont(Font.font("Forte", 35));
        enter.setFill(Color.WHITE);
        enter.setStroke(Color.BLACK);
        enter.setUnderline(true);
        TextField N = new TextField();
        Button show = new Button("Show");
        show.setBackground(Background.fill(Color.WHITE));
        show.setTextFill(Color.GREEN);
        show.setBorder(Border.stroke(Color.BLACK));
        hb.getChildren().addAll(enter, N, show);
        hb.setSpacing(20);
        hb.setTranslateX(275);
        hb.setTranslateY(30);
        Button back = new Button("BACK");
        back.setGraphic(backview);
        back.setFont(Font.font("Forte", 20));
        back.setBackground(Background.fill(Color.WHITE));
        back.setTextFill(Color.GREEN);
        back.setBorder(Border.stroke(Color.BLACK));
        back.setTranslateX(1050);
        back.setTranslateY(700);
        Rectangle rec2 = new Rectangle(660, 600);
        rec2.setFill(Color.TRANSPARENT);
        rec2.setStroke(Color.WHITE);
        rec2.setStrokeWidth(6);
        rec2.setTranslateX(500);
        rec2.setTranslateY(80);
        Rectangle rec3 = new Rectangle(300, 60);
        rec3.setFill(Color.TRANSPARENT);
        rec3.setStroke(Color.WHITE);
        rec3.setStrokeWidth(6);
        rec3.setTranslateX(80);
        rec3.setTranslateY(100);
        Rectangle rec4 = new Rectangle(350, 300);
        rec4.setFill(Color.TRANSPARENT);
        rec4.setStroke(Color.WHITE);
        rec4.setStrokeWidth(6);
        rec4.setTranslateX(75);
        rec4.setTranslateY(180);
        Text size = new Text();
        size.setFont(Font.font("Bold", 20));
        size.setFill(Color.WHITE);
        size.setTranslateX(90);
        size.setTranslateY(140);
        TextArea students = new TextArea();
        students.setFont(Font.font("Bold", 15));
        students.setTranslateX(540);
        students.setTranslateY(120);
        students.setMaxSize(800,1000);
        students.setEditable(true);
        Text function = new Text();
        function.setFont(Font.font("Bold", 20));
        function.setFill(Color.WHITE);
        function.setTranslateX(90);
        function.setTranslateY(220);
        Button insertst = new Button("INSERT");
        insertst.setFont(Font.font("Forte", 20));
        insertst.setBackground(Background.fill(Color.WHITE));
        insertst.setTextFill(Color.GREEN);
        insertst.setBorder(Border.stroke(Color.BLACK));
        insertst.setTranslateX(70);
        insertst.setTranslateY(550);
        Button searchst = new Button("SEARCH");
        searchst.setFont(Font.font("Forte", 20));
        searchst.setBackground(Background.fill(Color.WHITE));
        searchst.setTextFill(Color.GREEN);
        searchst.setBorder(Border.stroke(Color.BLACK));
        searchst.setTranslateX(200);
        searchst.setTranslateY(550);
        Button delst = new Button("DELETE");
        delst.setFont(Font.font("Forte", 20));
        delst.setBackground(Background.fill(Color.WHITE));
        delst.setTextFill(Color.GREEN);
        delst.setBorder(Border.stroke(Color.BLACK));
        delst.setTranslateX(200);
        delst.setTranslateY(650);
        Button savefile = new Button("SAVE");
        savefile.setFont(Font.font("Forte", 20));
        savefile.setBackground(Background.fill(Color.WHITE));
        savefile.setTextFill(Color.GREEN);
        savefile.setBorder(Border.stroke(Color.BLACK));
        savefile.setTranslateX(70);
        savefile.setTranslateY(650);
        LinkedList<Student> studentLinkedList = new LinkedList<Student>();
        LinkedList<Student>[] hashtable = new LinkedList[11];
        back.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                root2.getChildren().removeAll(back, search, insert, Delete, height, insertname, inname, insertfile, infile, save, namedel, del, hit, search2, name, result, depart, hb, students, rec2);
                root3.getChildren().removeAll(hb, back, students, rec2,rec3,size,function,rec4,insertst,searchst,delst,savefile);
                stage.setScene(scene);
            }
        });
        FileChooser chooser = new FileChooser();
        chooser.setTitle("Open departments file");

        dep.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {

                stage.setScene(scene2);
                root2.getChildren().addAll(back, search, insert, Delete, height);

                File file1 = chooser.showOpenDialog(stage);
                if (file1 != null) {

                    String filePath = file1.getPath();
                    try {
                        BufferedReader reader = new BufferedReader(new FileReader(filePath));
                        String line;

                        while ((line = reader.readLine()) != null) {
                            String[] arr = line.trim().split("/");
                            Department d = new Department(arr[0].trim(), arr[1].trim());
                            deps.insert(d);
                        }

                        reader.close();

                    } catch (IOException ioe) {
                        Alert alert = new Alert(Alert.AlertType.INFORMATION);
                        alert.setTitle("ERORR!!!!");
                        alert.setHeaderText("Alert!");
                        alert.setContentText(ioe.getMessage());
                    }
                }
                depart.setText(deps.traverse());


                search.setOnAction(new EventHandler<ActionEvent>() {

                    @Override
                    public void handle(ActionEvent event) {
                        root2.getChildren().removeAll(insertname, inname, insertfile, infile, save, namedel, del, hit);
                        root2.getChildren().addAll(search2, name);
                        search.setDisable(true);
                        insert.setDisable(false);
                        Delete.setDisable(false);
                        height.setDisable(false);
                        search2.setOnAction(new EventHandler<ActionEvent>() {

                            @Override
                            public void handle(ActionEvent event) {

                                root2.getChildren().addAll(result);
                                result.setText(deps.search(new Department(name.getText())).toString() + "\n Student file: " + deps.search(new Department(name.getText())).toString2());
                            }
                        });
                    }
                });
                insert.setOnAction(new EventHandler<ActionEvent>() {

                    @Override
                    public void handle(ActionEvent event) {
                        root2.getChildren().removeAll(search2, name, result, namedel, del, hit);
                        search.setDisable(false);
                        insert.setDisable(true);
                        Delete.setDisable(false);
                        height.setDisable(false);

                        root2.getChildren().addAll(insertname, inname, insertfile, infile, save);
                    }
                });
                save.setOnAction(new EventHandler<ActionEvent>() {

                    @Override
                    public void handle(ActionEvent event) {
                        Department de = new Department();
                        de.setDepname(inname.getText());
                        de.setDepstudents(infile.getText());
                        inname.clear();
                        infile.clear();
                        deps.insert(de);
                        depart.setText(deps.traverse());
                    }
                });
                Delete.setOnAction(new EventHandler<ActionEvent>() {

                    @Override
                    public void handle(ActionEvent event) {
                        root2.getChildren().removeAll(search2, name, result, insertname, inname, insertfile, infile, save, hit);
                        Delete.setDisable(true);
                        search.setDisable(false);
                        insert.setDisable(false);
                        height.setDisable(false);
                        root2.getChildren().addAll(namedel, del);
                    }
                });
                del.setOnAction(new EventHandler<ActionEvent>() {

                    @Override
                    public void handle(ActionEvent event) {
                        Department deldep = new Department(namedel.getText());
                        namedel.clear();
                        deps.delete(deldep);
                        depart.setText(deps.traverse());
                    }
                });
                height.setOnAction(new EventHandler<ActionEvent>() {

                    @Override
                    public void handle(ActionEvent event) {
                        root2.getChildren().removeAll(search2, name, result, insertname, inname, insertfile, infile, save, namedel, del);
                        height.setDisable(true);
                        search.setDisable(false);
                        insert.setDisable(false);
                        Delete.setDisable(false);
                        root2.getChildren().addAll(hit);
                        hit.setText("" + deps.height());
                    }
                });


                root2.getChildren().addAll(depart);

            }
        });
        student.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {

                root3.getChildren().addAll(hb, back);
                show.setOnAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent actionEvent) {
                        Department st = new Department(N.getText());
                        String s = deps.search(st).depstudents.trim();
                        Student student = null;

                        for (int i = 0; i < hashtable.length; i++) {
                            hashtable[i] = new LinkedList<>();
                        }
                        ClassLoader classLoader = getClass().getClassLoader();
                        File file = new File(classLoader.getResource(s).getFile());
                        try {
                            InputStream inputStream = new FileInputStream(file);
                        } catch (FileNotFoundException e) {
                            e.printStackTrace();
                        }
                        if (file != null) {

                            try {
                                BufferedReader reader = new BufferedReader(new FileReader(file));
                                String line;

                                while ((line = reader.readLine()) != null) {
                                    String[] arr = line.trim().split("/");
                                    student = new Student(arr[0].trim(), Long.parseLong(arr[1].trim()), Double.parseDouble(arr[2].trim()), arr[3].trim().charAt(0));
                                    studentLinkedList.insert(student);
                                }

                                reader.close();

                            } catch (IOException ioe) {
                                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                                alert.setTitle("ERORR!!!!");
                                alert.setHeaderText("Alert!");
                                alert.setContentText(ioe.getMessage());
                            }
                        }
                        LinkNode<Student> curr = studentLinkedList.getHead();
                        while (curr != null) {
                            int v = Hashcode(curr.data.namest);
                            hashtable[v].insert(curr.data);
                            curr = curr.next;

                        }
                        String c = "";
                        for (int j = 0; j < hashtable.length; j++) {
                            c = c + hashtable[j].toString2(j) + "\n";
                        }
                        students.setText(c);
                        size.setText("Size: "+ hashtable.length);
                        function.setText("Hash Function:\n" +"public int Hashcode(String s) {\n"+
                            "String[] m = s.trim().split();\n"+
                            "int n1, n2, n3;\n"+
                            "n1 = m[1].charAt(m[1].length() - 1);\n"+
                            "n2 = m[1].charAt(m[1].length() - 2);\n"+
                            "n3 = m[1].charAt(m[1].length() - 3);\n"+
                            "long sum = n1 + n2 + n3;\n"+
                            "int code = (int) sum % 11;\n"+
                            "return code;}");
                        root3.getChildren().addAll(students, rec2, rec3,size,function,rec4,insertst,searchst,delst,savefile);

                    }
                });
                stage.setScene(scene3);
            }
        });
        insertst.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                insertstage.setScene(scene4);
                insertstage.show();
                TextField in1= new TextField();
                in1.setPromptText("Name");
                TextField in2= new TextField();
                in2.setPromptText("ID");
                TextField in3 = new TextField();
                in3.setPromptText("Average");
                TextField in4 =new TextField();
                in4.setPromptText("Gender");
                in1.setTranslateY(20);
                in1.setTranslateX(100);
                in2.setTranslateY(50);
                in2.setTranslateX(100);
                in3.setTranslateY(80);
                in3.setTranslateX(100);
                in4.setTranslateY(110);
                in4.setTranslateX(100);
                Button savestudent = new Button("SAVE");
                savestudent.setFont(Font.font("Forte", 20));
                savestudent.setBackground(Background.fill(Color.WHITE));
                savestudent.setTextFill(Color.GREEN);
                savestudent.setBorder(Border.stroke(Color.BLACK));
                savestudent.setTranslateX(100);
                savestudent.setTranslateY(150);
                savestudent.setOnAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent actionEvent) {
                        Student student1 = new Student(in1.getText(),Long.parseLong(in2.getText()),Double.parseDouble(in3.getText()),in4.getText().charAt(0));
                        in1.clear();
                        in2.clear();
                        in3.clear();
                        in4.clear();
                        studentLinkedList.insert(student1);
                        int e = Hashcode(student1.namest);
                        hashtable[e].insert(student1);
                        String c = "";
                        for (int j = 0; j < hashtable.length; j++) {
                            c = c + hashtable[j].toString2(j) + "\n";
                        }
                        students.setText(c);
                    }
                });
                root4.getChildren().addAll(in1,in2,in3,in4,savestudent);


            }
        });
        searchst.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                delstage.setScene(scene5);
                delstage.show();
                TextField in1= new TextField();
                in1.setPromptText("Name");
                in1.setTranslateY(20);
                in1.setTranslateX(100);
                Button searchh = new Button("SEARCH");
                searchh.setFont(Font.font("Forte", 20));
                searchh.setBackground(Background.fill(Color.WHITE));
                searchh.setTextFill(Color.GREEN);
                searchh.setBorder(Border.stroke(Color.BLACK));
                searchh.setTranslateX(100);
                searchh.setTranslateY(100);
                searchh.setOnAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent actionEvent) {
                        Student student2 = new Student(in1.getText());
                        in1.clear();
                        Text res = new Text();
                        res.setFont(Font.font("Bold", 20));
                        res.setFill(Color.WHITE);
                        res.setTranslateX(50);
                        res.setTranslateY(200);
                        String information ="";
                        LinkNode<Student> inf = studentLinkedList.search(student2);
                        information = inf.toString();
                        res.setText( information);
                        root5.getChildren().addAll(res);
                    }
                });
                root5.getChildren().addAll(in1,searchh);

            }
        });
        savefile.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                try {
                    PrintWriter writer = new PrintWriter("HashTable.txt");
                    for(int r=0; r<hashtable.length; r++){
                        writer.append(hashtable[r].toString2(r));
                    }
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
            }
        });

        root1.getChildren().addAll(rec, imageView, dep, student);


        stage.setScene(scene);
        stage.show();
    }

    public int Hashcode(String s) {
        String[] m = s.trim().split(" ");
        int n1, n2, n3;
        n1 = m[1].charAt(m[1].trim().length()-1);
        n2 = m[1].charAt(m[1].trim().length()-1);
        n3 = m[1].charAt(m[1].trim().length()-1);
        long sum = n1 + n2 + n3;
        int code = (int) sum % 11;

        return code;
    }
}