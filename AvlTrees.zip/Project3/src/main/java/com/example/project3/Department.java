package com.example.project3;

public class Department implements Comparable<Department> {
    String depname;
    String depstudents;

    public Department(String depname, String depstudents) {
        this.depname = depname;
        this.depstudents = depstudents;
    }

    public Department() {

    }

    public String getDepname() {
        return depname;
    }

    public void setDepname(String depname) {
        this.depname = depname;
    }

    public String getDepstudents() {
        return depstudents;
    }

    public void setDepstudents(String depstudents) {
        this.depstudents = depstudents;
    }

    @Override
    public String toString() {
        return "----->  "+ depname ;
    }

    public String toString2() {
        return "" + depstudents;
    }

    public Department(String depname) {
        this.depname = depname;
    }

    @Override
    public int compareTo(Department o) {
        if(depname.compareToIgnoreCase(o.depname)>0){
            return 1;
        }
        else if(depname.compareToIgnoreCase(o.depname)<0){
            return -1;
        }
        else
        return 0;
    }
}
