package com.example.project3;

public class AVL<T extends Comparable<T>> {
    private Node<T> root;

    public void insert(T data) {
        if (root == null) {
            root = new Node<T>(data);
            return;
        }
        Node<T> curr = root, newNode = new Node<T>(data);
        while (true) {
            if (curr.getData().compareTo(data) > 0) if (curr.getLeft() != null) curr = curr.getLeft();
            else {
                curr.setLeft(newNode);
                return;
            }
            else if (curr.getRight() != null) curr = curr.getRight();
            else {
                curr.setRight(newNode);
                return;
            }

        }
    }

    public T search(T key) {
        return search(root, key);
    }

    private T search(Node<T> node, T key) {
        if (node != null) {
            if (node.getData().compareTo(key) > 0) return search(node.getLeft(), key);
            else if (node.getData().compareTo(key) < 0) return search(node.getRight(), key);
            else return node.getData();
        }

        return null;
    }

    public T min() {
        if (root == null) return null;

        Node<T> curr = root;
        while (curr.getLeft() != null) curr = curr.getLeft();

        return curr.getData();
    }

    public T max() {
        if (root == null) return null;

        Node<T> curr = root;
        while (curr.getRight() != null) curr = curr.getRight();

        return curr.getData();
    }

    public void traverseLevel() {
        int h = height(root, 0);
        int i;
        for (i = 0; i <= h; i++) {
            printCurrentLevel(root, i, 0);
            System.out.println();
        }
    }

    public String traverse() {
        return traverse(root);
    }

    void printCurrentLevel(Node<T> root, int level, int i) {
        if (root == null) return;
        if (level == i) System.out.println(root.getData() + " ");
        else printCurrentLevel(root.getLeft(), level, i + 1);
        printCurrentLevel(root.getRight(), level, i + 1);

    }

    private String traverse(Node<T> curr) {
        if (curr != null) return traverse(curr.getLeft()) + "\n" + curr + "\n" + traverse(curr.getRight());

        return "";
    }

    public Node<T> getRoot() {
        return root;
    }

    public int countLeef() {
        return countLeef(root);
    }

    private int countLeef(Node<T> curr) {
        if (curr != null) {
            if (curr.isLeaf()) return 1;
            else return countLeef(curr.getLeft()) + countLeef(curr.getRight());
        }
        return 0;
    }

    public int countNotLeef() {
        return countNotLeef(root);
    }

    private int countNotLeef(Node<T> curr) {
        if (curr != null) {
            if (!curr.isLeaf()) return 1 + countNotLeef(curr.getLeft()) + countNotLeef(curr.getRight());
            else return 0;
        }
        return 0;
    }

    public int height() {
        return height(root, 0);
    }

    private int height(Node<T> root, int i) {
        if (root == null) return i;

        return Math.max(height(root.getLeft(), i + 1), height(root.getRight(), i + 1));

    }

    public Node<T> delete(T data) {
        Node<T> current = root;
        Node<T> parent = root;
        boolean isLeftChild = false;
        if (isEmpty()) return null;
        while (current != null && !current.getData().equals(data)) {
            parent = current;
            if (data.compareTo(current.getData()) < 0) {
                current = current.getLeft();
                isLeftChild = true;
            } else {
                current = current.getRight();
                isLeftChild = false;
            }
        }
        if (current == null) return null;
        if (!current.hasLeft() && !current.hasRight()) {
            if (current == root) root = null;
            else {
                if (isLeftChild) parent.setLeft(null);
                else parent.setRight(null);
            }
        } else if (current.hasLeft() && !current.hasRight()) {
            if (current == root) {
                root = current.getLeft();
            } else if (isLeftChild) {
                parent.setLeft(current.getLeft());
            } else {
                parent.setRight(current.getLeft());
            }
        } else if (current.hasRight() && !current.hasRight()) {
            if (current == root) {
                root = current.getRight();
            } else if (isLeftChild) {
                parent.setLeft(current.getRight());
            } else {
                parent.setRight(current.getRight());
            }
        } else {
            Node<T> successor = getSuccessor(current);
            if (current == root) root = successor;
            else if (isLeftChild) {
                parent.setLeft(successor);
            } else {
                parent.setRight(successor);
            }
            successor.setLeft(current.getLeft());
        }
        return current;
    }

    private Node<T> getSuccessor(Node<T> node) {
        Node<T> parentOfSuccessor = node;
        Node<T> successor = node;
        Node<T> current = node.getRight();
        while (current != null) {
            parentOfSuccessor = successor;
            successor = current;
            current = current.getLeft();
        }
        if (successor.getData().compareTo(node.getRight().getData()) != 0) { // fix successor connections
            parentOfSuccessor.setLeft(successor.getRight());
            successor.setRight(node.getRight());
        }
        return successor;
    }

    public boolean isEmpty() {
        return root == null;
    }
}