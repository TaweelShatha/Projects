package com.example.project3;

import java.util.Objects;

public class Student implements Comparable<Student> {
    String namest;
    long id;
    double avg;
    char gender;

    public Student(String namest, long id, double avg, char gender) {
        this.namest = namest;
        this.id = id;
        this.avg = avg;
        this.gender = gender;
    }

    public String getNamest() {
        return namest;
    }

    public void setNamest(String namest) {
        this.namest = namest;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public double getAvg() {
        return avg;
    }

    public void setAvg(double avg) {
        this.avg = avg;
    }

    public char getGender() {
        return gender;
    }

    public void setGender(char gender) {
        this.gender = gender;
    }

    @Override
    public String toString() {
        return "Name: " + namest +", ID: " + id + ", Average: " + avg + ", Gender: " + gender + "\n";
    }

    public Student(String namest) {
        this.namest = namest;
    }

    public Student(long id) {
        this.id = id;
    }

    @Override
    public int compareTo(Student o) {
        if(namest.compareToIgnoreCase(o.namest)>0){
            return 1;
        }
        else if(namest.compareToIgnoreCase(o.namest)<0){
            return -1;
        }
        else
            return 0;
    }
}
