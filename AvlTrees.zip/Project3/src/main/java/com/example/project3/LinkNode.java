package com.example.project3;

public class LinkNode<T extends Comparable<T>> {

    T data;
    LinkNode next;


    public LinkNode(T data) {
        super();
        this.data = data;
    }

    public LinkNode(T data, LinkNode next) {
        this.data = data;
        this.next = next;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }

    public LinkNode getNext() {
        return next;
    }

    public void setNext(LinkNode next) {
        this.next = next;
    }

    public String toString() {
        return "" + data;
    }
}
