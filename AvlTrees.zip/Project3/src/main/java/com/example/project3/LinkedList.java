package com.example.project3;


public class LinkedList<T extends Comparable<T>> {

    private LinkNode<T> head;

    public LinkedList(LinkNode<T> head) {
        super();
        this.head = head;
    }

    public LinkedList() {
        // TODO Auto-generated constructor stub
    }

    public LinkNode<T> getHead() {
        return head;
    }

    public void setHead(LinkNode<T> head) {
        this.head = head;
    }

    public void insert(T data) {
        LinkNode<T> newnode = new LinkNode<T>(data);
        LinkNode<T> prev = null, curr = head;
        for (; curr != null && curr.data.compareTo(data) < 0; prev = curr, curr = curr.next)
            ;

        if (head == null) {
            head = newnode;
        } else if (curr == head) {
            newnode.next = head;
            head = newnode;
        } else if (curr == null) {
            newnode.next = curr;
            prev.next = newnode;
        } else {
            newnode.next = curr;
            prev.next = newnode;
        }

    }

    public void traverse() {
        LinkNode<T> curr = head;
        System.out.print("Head --->");
        while (curr != null) {
            System.out.print("[" + curr + "]----->");
            curr = curr.next;
        }
        System.out.println("Null");
    }

    public void Delete(T data) {
        LinkNode<T> prev = null, curr = head;
        for (; curr != null && curr.data.compareTo(data) < 0; prev = curr, curr = curr.next)
            ;
        if (curr == null || !curr.data.equals(data)) {
            System.out.println("Data not found");

        } else {
            if (curr == head) head = head.next;
            else prev.next = curr.next;
        }

    }

    public LinkNode<T> search(T data) {
        LinkNode curr = head;

        while ((curr != null) && (curr.data.compareTo(data)!=0)){
            curr = curr.next;
        }

        if (curr == null){
            System.out.println("Not found!");
            return null;
        }
        else return curr;
    }

    @Override
    public String toString() {
        String s="";
        LinkNode<T> curr= head;
        while(curr!=null){
            s= s + curr.data + "\n";
            curr = curr.next;
        }
        return s;
    }
    public String toString2(int a) {
        String s=a+": ";
        LinkNode<T> curr= head;
        while(curr!=null){
            s= s + curr.data + "\n";
            curr = curr.next;
        }
        return s;
    }
}
