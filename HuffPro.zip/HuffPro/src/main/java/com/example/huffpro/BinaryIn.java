package com.example.huffpro;

import java.io.*;
import java.util.NoSuchElementException;


public class BinaryIn {
    static final int EOF = -1;

    static BufferedInputStream in;
    static FileInputStream infile;
    static int buffer;
    static int n;
    static boolean isInitialized;

    public BinaryIn(File f) throws FileNotFoundException {
        BinaryIn.infile = new FileInputStream(f);
        initialize();

    }

    private void initialize() {
        in = new BufferedInputStream(infile);
        buffer = 0;
        n = 0;
        fillBuffer();
        isInitialized = true;
    }

    private void fillBuffer() {
        try {
            buffer = in.read();
            n = 8;
        } catch (IOException e) {
            System.out.println("EOF");
            buffer = EOF;
            n = -1;
        }
    }

    void close() {
        if (!isInitialized)
            initialize();
        try {
            in.close();
            isInitialized = false;
        } catch (IOException ioe) {
            throw new IllegalStateException("Could not close BinaryStdIn", ioe);
        }
    }

    private boolean isEmpty() {
        if (!isInitialized)
            initialize();

        return buffer == -1;
    }

    public boolean readBoolean() {
        if (isEmpty())
            throw new NoSuchElementException("Reading from empty input stream");
        n--;
        boolean bit = ((buffer >> n) & 1) == 1;
        if (n == 0)
            fillBuffer();
        return bit;
    }

    public char readChar() {
        if (isEmpty())
            throw new NoSuchElementException("Reading from empty input stream");

        if (n == 8) {
            int x = buffer;
            fillBuffer();
            return (char) (x & 0xff);
        }

        int x = buffer;
        x <<= (8 - n);
        int oldN = n;
        fillBuffer();
        if (isEmpty())
            throw new NoSuchElementException("Reading from empty input stream");
        n = oldN;
        x |= (buffer >>> n);
        return (char) (x & 0xff);
    }

    public byte readByte() {
        char c = readChar();
        return (byte) (c & 0xff);
    }
}
