package com.example.huffpro;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.image.Image;
import javafx.scene.layout.Background;
import javafx.scene.layout.Border;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Ellipse;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.*;
import java.util.ArrayList;
import java.util.PriorityQueue;

public class HelloApplication extends Application {
    private static int headLength = 0;
    private static int actualfileLength;
    private static double rate = 0;
    private static String s = "";
    private static int frq[];
    private static byte[] bytes;
    private static int numOfChar = 0;
    private static PriorityQueue<HuffmanNode> heap;
    private static HuffmanNode huffmanTreeRoot;
    private static ArrayList<Node> huffmanCodes;
    private static File inputUnCompressionFile, inputDeCompressionFile;
    private static String typeFile = "";
    private static String headerLength = "";
    private static String dataLength = "";

    private static HuffmanNode decodeHeader() {

        String st = peek(1);
        boolean n = st.equals("");
        if (n) return null;
        boolean isLeaf = st.equals("1");

        if (isLeaf) {

            byte b = (byte) ((Integer.parseInt(peek(8), 2)) - 128);
            return new HuffmanNode(b, -1, null, null, true);
        }

        return new HuffmanNode(decodeHeader(), decodeHeader());

    }

    private static String getByteBinaryString(byte b) {

        StringBuilder sb = new StringBuilder();
        for (int i = 7; i >= 0; --i) {
            sb.append(b >>> i & 1);
        }
        return sb.toString();
    }

    private static ArrayList<Node> addCode(HuffmanNode root) {
        ArrayList<Node> huffmanCodes = new ArrayList<Node>();
        String s = ("");
        addCode(root, s, huffmanCodes);

        return huffmanCodes;

    }

    private static void addCode(HuffmanNode root, String s, ArrayList<Node> huffmanCodes) {
        if (!(root.isLeaf())) {
            String sl = s + "0";
            String sr = s + "1";
            addCode(root.getLeft(), sl, huffmanCodes);
            addCode(root.getRight(), sr, huffmanCodes);
        } else {
            huffmanCodes.add(new Node(s.toString(), root));
        }
    }

    private static void buildHeader(HuffmanNode huffmanTreeRoot, BinaryOut bos) throws IOException {
        if (huffmanTreeRoot.isLeaf()) {
            bos.write(true);
            String s = getByteBinaryString(huffmanTreeRoot.getVal());
            for (int i = 0; i < s.length(); i++) {
                if (s.charAt(i) == '1') bos.write(true);

                else bos.write(false);

            }
            return;

        }

        bos.write(false);
        buildHeader(huffmanTreeRoot.getLeft(), bos);
        buildHeader(huffmanTreeRoot.getRight(), bos);
    }

    private static void getHeaderLength(HuffmanNode huffmanTreeRoot) {
        if (huffmanTreeRoot == null) return;
        if (huffmanTreeRoot.isLeaf()) {
            headLength += 9;
            return;
        } else {
            headLength++;
            getHeaderLength(huffmanTreeRoot.getLeft());
            getHeaderLength(huffmanTreeRoot.getRight());
        }

    }

    private static String peek(int i) {
        if (i > s.length()) return "";
        String r = s.substring(0, i);
        s = s.substring(i);
        return r;
    }

    private static void readFile(File uncompressedFile) throws IOException {

        bytes = new byte[(int) uncompressedFile.length()];
        // read file as bytes
        try (FileInputStream inputStream = new FileInputStream(uncompressedFile)) {// fileinputStream
            inputStream.read(bytes);
        }

        frq = new int[256];

        for (int i = 0; i < bytes.length; i++)
            frq[bytes[i] + 128]++;

        for (int i = 0; i < frq.length; i++)
            if (frq[i] > 0) numOfChar++;

    }

    private static void initializePriorityQueue() {
        heap = new PriorityQueue<>();

        for (int i = 0; i < frq.length; i++)
            if (frq[i] > 0) heap.add(new HuffmanNode(frq[i], (byte) i, true));

    }

    private static void buildHuffmanTree() {
        while (heap.size() > 1) {
            HuffmanNode node = new HuffmanNode(0);

            HuffmanNode left = (HuffmanNode) heap.poll();
            HuffmanNode right = (HuffmanNode) heap.poll();

            node.addLift(left);

            node.addRight(right);

            heap.add(node);

        }

        huffmanTreeRoot = (HuffmanNode) heap.peek();

    }

    public static void main(String[] args) {
        launch();
    }

    @Override
    public void start(Stage stage) throws Exception {

        Pane root = new Pane();
        root.setBackground(Background.fill(Color.LAVENDER));
        Scene scene = new Scene(root, 1000, 750);
        stage.setScene(scene);
        stage.getIcons().add(new Image("file:archive.png"));
        stage.setTitle("Huffman File Manager");
        Label title = new Label("Compress & Decompress files!");
        title.setFont(new Font("Veranda", 34));
        title.setTextFill(Color.PURPLE);
        title.setAlignment(Pos.TOP_CENTER);
        title.setTranslateX(270);
        Label compressor = new Label("Compressor");
        compressor.setFont(new Font("Veranda", 24));
        compressor.setTextFill(Color.PURPLE);
        Label decompressor = new Label("Decompressor");
        decompressor.setFont(new Font("Veranda", 24));
        decompressor.setTextFill(Color.PURPLE);
        Button close = new Button("Exit");
        close.setBackground(Background.fill(Color.PURPLE));
        close.setTextFill(Color.WHITE);
        close.setPrefWidth(100);
        close.setFont(new Font("Veranda", 16));
        close.setTranslateX(450);
        close.setTranslateY(700);
        close.setShape(new Ellipse(40, 60));
        Button compFilChooser = new Button("Select File!");
        compFilChooser.setTextFill(Color.WHITE);
        compFilChooser.setBackground(Background.fill(Color.PURPLE));
        compFilChooser.setFont(new Font("Veranda", 15));
        Button deCompFilChooser = new Button("Select File!");
        deCompFilChooser.setBackground(Background.fill(Color.PURPLE));
        deCompFilChooser.setTextFill(Color.WHITE);
        deCompFilChooser.setFont(new Font("Veranda", 15));
        TextArea ta = new TextArea("");
        ta.setPrefHeight(550);
        ta.setFont(new Font("Veranda", 13));
        ta.setTranslateY(120);
        ta.setTranslateX(270);
        ta.setBorder(Border.stroke(Color.PURPLE));
        VBox compVBox = new VBox(20, compressor, compFilChooser);
        compVBox.setTranslateY(150);
        compVBox.setTranslateX(50);
        VBox deCompVBox = new VBox(20, decompressor, deCompFilChooser);
        deCompVBox.setTranslateX(50);
        deCompVBox.setTranslateY(350);
        root.getChildren().addAll(title, compVBox, deCompVBox, ta, close);
        close.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                System.exit(0);
            }
        });

        FileChooser compChooser = new FileChooser();
        compChooser.getExtensionFilters().addAll(new FileChooser.ExtensionFilter("All Files", "*.*"), new FileChooser.ExtensionFilter("Text Files", "*.txt"), new FileChooser.ExtensionFilter("Java Files", "*.java"), new FileChooser.ExtensionFilter("Web Files", "*.html", "*.css", "*.js", "*.php"), new FileChooser.ExtensionFilter("Image files", "*.png", "*.jpg"), new FileChooser.ExtensionFilter("Word files", "*.docx"), new FileChooser.ExtensionFilter("Pdf files", "*.pdf")

        );

        EventHandler<ActionEvent> event = new EventHandler<ActionEvent>() {

            public void handle(ActionEvent e) {

                inputUnCompressionFile = compChooser.showOpenDialog(stage);

                if (inputUnCompressionFile != null) {

                    try {
                        comp(stage, compVBox, deCompVBox, ta);
                        Button tree = new Button("Show Huffman Tree");
                        tree.setBackground(Background.fill(Color.PURPLE));
                        tree.setTextFill(Color.WHITE);
                        tree.setFont(new Font("Veranda", 16));
                        tree.setTranslateX(820);
                        tree.setTranslateY(120);
                        root.getChildren().add(tree);
                        tree.setOnAction(new EventHandler<ActionEvent>() {
                            @Override
                            public void handle(ActionEvent actionEvent) {
                                Stage newstage = new Stage();
                                newstage.setTitle("Huffman Tree");
                                Pane root2 = new Pane();
                                root2.setBackground(Background.fill(Color.LAVENDER));
                                Scene treescene = new Scene(root2, 750, 500);
                                newstage.setScene(treescene);
                                newstage.show();
                                Text t = new Text();
                                t.setText("");
                                t.setFill(Color.PURPLE);
                                t.setFont(new Font("Veranda", 16));
                                t.setTranslateX(400);
                                t.setTranslateY(newstage.getHeight() / 4);
                                t.setText(printLevel(heap.peek(), 0, 0));


                                root2.getChildren().addAll(t);
                            }
                        });
                    } catch (FileNotFoundException e1) {
                        e1.printStackTrace();
                    } catch (IOException e1) {
                        e1.printStackTrace();
                    }
                }
            }
        };
        compFilChooser.setOnAction(event);
        FileChooser decompFileChooser = new FileChooser();
        decompFileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Huffman Files", "*.huff"));

        EventHandler<ActionEvent> event2 = new EventHandler<ActionEvent>() {

            public void handle(ActionEvent e) {

                // get the file selected
                inputDeCompressionFile = decompFileChooser.showOpenDialog(stage);

                if (inputDeCompressionFile != null) {

                    ta.setText("Decompression \n" + inputDeCompressionFile.getAbsolutePath() + "  <---- is selected");

                    try {
                        deComp(stage, deCompVBox, compVBox);
                    } catch (FileNotFoundException e1) {
                        e1.printStackTrace();
                    } catch (IOException e1) {
                        e1.printStackTrace();
                    }
                }
            }
        };
        deCompFilChooser.setOnAction(event2);

        stage.show();

    }

    private void deComp(Stage stage, VBox vb, VBox vb2) throws IOException {

        if (vb.getChildren().size() > 2) {
            vb.getChildren().remove(2);
            vb2.getChildren().remove(2);
        }
        Button button = new Button("Save a Uncomparsion file");
        button.setFont(new Font("veranda", 16));
        button.setBackground(Background.fill(Color.PURPLE));
        button.setTextFill(Color.WHITE);
        vb.getChildren().add(button);
        Button bu = new Button("Save a comparsion file");
        bu.setFont(new Font("Veranda", 16));
        bu.setBackground(Background.fill(Color.PURPLE));
        bu.setTextFill(Color.WHITE);
        vb2.getChildren().add(bu);


        BinaryIn binaryRead = new BinaryIn(inputDeCompressionFile);
        button.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                splitHeader(binaryRead);

                FileChooser fileChooser = new FileChooser();

                FileChooser.ExtensionFilter extFilter = new FileChooser.ExtensionFilter(typeFile + " files (*." + typeFile + ")", "*." + typeFile);
                fileChooser.getExtensionFilters().add(extFilter);

                File file = fileChooser.showSaveDialog(stage);

                if (file != null) {
                    FileOutputStream out = null;

                    try {
                        out = new FileOutputStream(file);
                        BinaryOut bout = new BinaryOut(out);

                        Long datalength = Long.parseLong(dataLength);

                        int length = Integer.parseInt(headerLength);

                        StringBuilder header = new StringBuilder("");

                        for (int i = 0; i < length; i++) {
                            boolean b = binaryRead.readBoolean();
                            if (b) header.append("1");
                            else header.append("0");

                        }

                        s = header.toString();

                        HuffmanNode root = decodeHeader();

                        for (int i = 0; i < datalength; i++) {
                            HuffmanNode node = root;
                            while (!node.isLeaf()) {
                                boolean bit = binaryRead.readBoolean();
                                if (bit) node = node.getRight();
                                else node = node.getLeft();
                            }
                            bout.write(node.getVal());
                        }
                        bout.close();

                    } catch (FileNotFoundException e1) {
                        System.out.println("File not found" + e1);
                    } finally {
                        try {
                            if (out != null) {
                                out.close();
                            }
                        } catch (IOException ioe) {
                            System.out.println("Error while closing stream: " + ioe);
                        }

                    }
                }
            }
        });


    }

    private void splitHeader(BinaryIn binaryRead) {

        boolean n = true;

        while (n) {
            char c = (char) binaryRead.readByte();
            if (c == ':') n = false;
            else typeFile += c;
        }
        n = true;
        while (n) {
            char c = (char) binaryRead.readByte();
            if (c == ':') n = false;
            else headerLength += c;
        }

        n = true;
        while (n) {
            char c = (char) binaryRead.readByte();
            if (c == ':') n = false;
            else dataLength += c;
        }

    }

    private void comp(Stage stage, VBox vb, VBox vb2, TextArea ta) throws IOException {

        numOfChar = 0;

        if (vb.getChildren().size() > 2) {
            vb.getChildren().remove(2);
            vb2.getChildren().remove(2);
        }
        Button button = new Button("Save a comparsion file");
        button.setFont(new Font("Arial", 12));

        Button bu = new Button("Save a comparsion file");
        bu.setFont(new Font("Arial", 12));
        bu.setVisible(false);
        vb2.getChildren().add(bu);
        String nameOfFile = inputUnCompressionFile.getName().split("\\.")[1];

        readFile(inputUnCompressionFile);

        vb.getChildren().addAll(button);

        ta.setText("\nInput File information: " + "  \n file selected: " + "File Path: " + inputUnCompressionFile.getAbsolutePath() + "\nFile length :" + inputUnCompressionFile.length() + "\nNumber of Characters: " + numOfChar + "\n *********************************" + "\nCompressed File Information " + "\nFile Head Length : " + headLength + "\n Actual Data Length : " + actualfileLength + "\nCompression Rate : " + rate + "%" + "\n ******************************************");


        button.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                FileChooser fileChooser = new FileChooser();

                FileChooser.ExtensionFilter extFilter = new FileChooser.ExtensionFilter("huff files (*.huff)", "*.huff");
                fileChooser.getExtensionFilters().add(extFilter);

                File file = fileChooser.showSaveDialog(stage);

                if (file != null) {

                    FileOutputStream outStream = null;

                    try {

                        outStream = new FileOutputStream(file);

                        BinaryOut binaryStrem = new BinaryOut(outStream);

                        BitOutput bitStream = new BitOutput(outStream);

                        initializePriorityQueue();
                        buildHuffmanTree();

                        getHeaderLength(huffmanTreeRoot);

                        bitStream.writeH(new StringBuilder(nameOfFile + ":" + headLength + ":"));

                        buildHeader(huffmanTreeRoot, binaryStrem);

                        huffmanCodes = addCode(huffmanTreeRoot);

                        writeCompressedData(bitStream, binaryStrem);
                        actualfileLength = (int) file.length();

                        rate = ((double) (bytes.length - actualfileLength) / bytes.length) * 100;
                        String ratio = rate + "";
                        if (ratio.length() > 5) {
                            ratio = ratio.substring(0, 5);
                        }

                        ta.setText(" ********************************************************" + "\nInput File information" + "\nFile Path:" + inputUnCompressionFile.getAbsolutePath() + "\nFile length :" + inputUnCompressionFile.length() + "\nNumber of Characters: " + numOfChar + "\n *********************************************" + "\nCompressed File Information " + "\nFile Head Length : " + headLength + "\n Actual Data Length : " + actualfileLength + "\nCompression Rate : " + ratio + "%" + "\n *******************************");

                        ta.setText(ta.getText() + "\n" + "Table of frequencies: \n" + "byte  ::: frequency ::: Huffman code" + "\n");
                        for (int i = 0; i < huffmanCodes.size(); i++) {
                            ta.setText(ta.getText() + "\n{" + (char) huffmanCodes.get(i).getVal().getVal() + "} ||      " + huffmanCodes.get(i).getVal().getFreq() + " ||     " + huffmanCodes.get(i).gethCode() + "\n");
                        }

                    } catch (FileNotFoundException e1) {
                        System.out.println("File not found" + e1);
                    } catch (IOException ioe) {
                        System.out.println("Exception while writing file " + ioe);
                    } finally {
                        try {
                            if (outStream != null) {
                                outStream.close();
                            }
                        } catch (IOException ioe) {
                            System.out.println("Error while closing stream: " + ioe);
                        }

                    }
                }
            }
        });

    }

    private void writeCompressedData(BitOutput bitStream, BinaryOut binaryStrem) throws IOException {

        StringBuilder s = new StringBuilder("");

        for (int i = 0; i < bytes.length; i++)
            for (int j = 0; j < huffmanCodes.size(); j++)
                if ((bytes[i]) == huffmanCodes.get(j).getVal().getVal()) {
                    s.append(huffmanCodes.get(j).gethCode());
                    break;
                }
        bitStream.writeH(new StringBuilder(bytes.length + ":"));

        for (int i = 0; i < s.length(); i++) {
            if (s.charAt(i) == '1') binaryStrem.write(true);
            else if (s.charAt(i) == '0') binaryStrem.write(false);
        }

        binaryStrem.close();
    }

    private String printLevel(HuffmanNode node, int level, int i) {
        if (node == null)
            return "";
        else {
            return " " + printLevel(node.getLeft(), level, i + 1) + ":" + node + ":" + printLevel(node.getRight(), level, i + 1) + "\n";
        }


    }

}