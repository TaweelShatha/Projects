package com.example.dynamicfinal;


import javafx.animation.PauseTransition;
import javafx.animation.SequentialTransition;
import javafx.animation.TranslateTransition;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.media.MediaView;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Ellipse;
import javafx.scene.shape.Line;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.IOException;
import java.util.Random;

public class HelloApplication extends Application {
    public static void main(String[] args) {
        launch();

    }

    public int[][] what_index(int[] Coins, int[][] table) {
        int[][] index = new int[Coins.length][Coins.length];
        for (int i = 0; i < Coins.length; i++) {
            index[i][i] = i;
        }
        for (int gap = 2; gap <= Coins.length; gap++) {
            for (int i = 0; i < Coins.length - gap + 1; ++i) {
                int j = i + gap - 1;
                if (j == i + 1) {
                    if (Coins[i] > Coins[j])
                        index[i][j] = i;
                    else
                        index[i][j] = j;
                } else {
                    if ((Coins[i] + Math.min(table[i + 2][j], table[i + 1][j - 1])) >= (Coins[j] + Math.min(table[i + 1][j - 1], table[i][j - 2])))
                        index[i][j] = i;
                    else
                        index[i][j] = j;
                }
            }
        }
        return index;
    }

    public void print(int[][] table, int[] Coins, int[][] index_table, Pane root) {
        Line line_x = new Line(0, 26, 1000, 26);
        Line line_y = new Line(35, 0, 35, 600);
        line_x.setStroke(Color.PURPLE);
        line_y.setStroke(Color.PURPLE);
        line_x.setStrokeWidth(3);
        line_y.setStrokeWidth(3);
        for (int i = 0; i < Coins.length; i++) {
            Label coin_x = new Label(String.valueOf(Coins[i]));
            coin_x.setFont(new Font("Veranda", 20));
            coin_x.setTextFill(Color.PURPLE);
            coin_x.setTranslateY(2);
            coin_x.setTranslateX(60 + (i * 70));
            Label coin_y = new Label(String.valueOf(Coins[i]));
            coin_y.setFont(new Font("Veranda", 20));
            coin_y.setTextFill(Color.PURPLE);
            coin_y.setTranslateY(30 + (i * 40));
            coin_y.setTranslateX(2);
            root.getChildren().addAll(coin_x, coin_y);
        }
        for (int i = 0; i < table.length; i++) {
            for (int j = 0; j < table.length; j++) {
                Label index = new Label(String.valueOf(table[j][i]) + ":" + String.valueOf(index_table[j][i]));
                index.setTranslateX(50 + (i * 70));
                index.setTranslateY(30 + (j * 40));
                index.setFont(new Font("Veranda", 20));
                index.setTextFill(Color.PURPLE);
                root.getChildren().add(index);
            }
        }
        root.getChildren().addAll(line_x, line_y);
    }

    public int[] ChoosenNumb(int[][] index_table, int[] Coins) {
        int[] indx_arr = new int[(Coins.length)];
        int i = 0;
        int j = Coins.length - 1;
        int contuer = 0;
        while (contuer <= Coins.length - 1) {
            if (index_table[i][j] == i) {
                indx_arr[contuer] = i;
                i++;
            } else {
                indx_arr[contuer] = j;
                j--;
            }
            contuer++;
        }
        return indx_arr;
    }


    @Override

    public void start(Stage stage) throws IOException {
        Pane pane = new Pane();
        Scene sceneone = new Scene(pane, 1250, 750);
        pane.setBackground(Background.fill(Color.BISQUE));
        stage.setTitle("Coin Greed!");
        Image icon = new Image("file:coin.png");
        stage.getIcons().add(icon);
        DropShadow glow = new DropShadow(20, Color.WHITE);
        Button play = new Button("Play!");
        play.setBackground(Background.fill(Color.PURPLE));
        play.setPrefSize(300, 100);
        play.setShape(new Ellipse(20, 30));
        play.setTextFill(Color.WHITE);
        play.setFont(Font.font("Verdana", FontWeight.BOLD, 18));
        play.setEffect(glow);
        Button Table = new Button("Show Me The Table!");
        Table.setBackground(Background.fill(Color.PURPLE));
        Table.setPrefSize(300, 100);
        Table.setShape(new Ellipse(20, 30));
        Table.setTextFill(Color.WHITE);
        Table.setFont(Font.font("Verdana", FontWeight.BOLD, 18));
        Table.setDisable(true);
        Table.setEffect(glow);
        Button result = new Button("Max Money");
        result.setBackground(Background.fill(Color.PURPLE));
        result.setPrefSize(300, 100);
        result.setShape(new Ellipse(20, 30));
        result.setTextFill(Color.WHITE);
        result.setFont(Font.font("Verdana", FontWeight.BOLD, 18));
        result.setDisable(true);
        result.setEffect(glow);
        Button how = new Button("Show Me How!");
        how.setBackground(Background.fill(Color.PURPLE));
        how.setPrefSize(300, 100);
        how.setShape(new Ellipse(20, 30));
        how.setTextFill(Color.WHITE);
        how.setFont(Font.font("Verdana", FontWeight.BOLD, 18));
        how.setDisable(true);
        how.setEffect(glow);
        VBox buttons = new VBox();
        buttons.getChildren().addAll(play, Table, result, how);
        buttons.setSpacing(10);
        buttons.setTranslateX(40);
        buttons.setTranslateY(50);
        pane.getChildren().addAll(buttons);
        Circle one = new Circle(40, Color.SILVER);
        one.setStroke(Color.WHITE);
        one.setStrokeWidth(1.5);
        Text num1 = new Text();
        num1.setFont(Font.font("Verdana", FontWeight.BOLD, 24));
        num1.setFill(Color.PURPLE);
        StackPane stackone = new StackPane();
        stackone.getChildren().addAll(one, num1);
        Circle two = new Circle(40, Color.SILVER);
        two.setStroke(Color.WHITE);
        two.setStrokeWidth(1.5);
        Text num2 = new Text();
        num2.setFont(Font.font("Verdana", FontWeight.BOLD, 24));
        num2.setFill(Color.PURPLE);
        StackPane stacktwo = new StackPane();
        stacktwo.getChildren().addAll(two, num2);
        Circle three = new Circle(40, Color.SILVER);
        three.setStroke(Color.WHITE);
        three.setStrokeWidth(1.5);
        Text num3 = new Text();
        num3.setFont(Font.font("Verdana", FontWeight.BOLD, 24));
        num3.setFill(Color.PURPLE);
        StackPane stackthree = new StackPane();
        stackthree.getChildren().addAll(three, num3);
        Circle four = new Circle(40, Color.SILVER);
        four.setStroke(Color.WHITE);
        four.setStrokeWidth(1.5);
        Text num4 = new Text();
        num4.setFont(Font.font("Verdana", FontWeight.BOLD, 24));
        num4.setFill(Color.PURPLE);
        StackPane stackfour = new StackPane();
        stackfour.getChildren().addAll(four, num4);
        Circle five = new Circle(40, Color.SILVER);
        five.setStroke(Color.WHITE);
        five.setStrokeWidth(1.5);
        Text num5 = new Text();
        num5.setFont(Font.font("Verdana", FontWeight.BOLD, 24));
        num5.setFill(Color.PURPLE);
        StackPane stackfive = new StackPane();
        stackfive.getChildren().addAll(five, num5);
        Circle six = new Circle(40, Color.SILVER);
        six.setStroke(Color.WHITE);
        six.setStrokeWidth(1.5);
        Text num6 = new Text();
        num6.setFont(Font.font("Verdana", FontWeight.BOLD, 24));
        num6.setFill(Color.PURPLE);
        StackPane stacksix = new StackPane();
        stacksix.getChildren().addAll(six, num6);
        HBox numbs = new HBox();
        numbs.setTranslateX(sceneone.getWidth() / 2);
        numbs.setTranslateY(20);
        numbs.setSpacing(6);
        int[] coins = new int[6];
        VBox dt = new VBox();
        Text data = new Text();
        Text res = new Text();
        Media media = new Media("file:/C:/Users/thinkpad/Desktop/confitte.mp4");
        MediaPlayer mediaPlayer = new MediaPlayer(media);
        MediaView mediaView = new MediaView(mediaPlayer);
        mediaView.setSmooth(true);
        StackPane answer = new StackPane();
        int[][] game = new int[6][6];
        play.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                play.setDisable(true);
                Table.setDisable(false);
                result.setDisable(false);
                how.setDisable(false);
                pane.getChildren().remove(numbs);
                numbs.getChildren().addAll(stackone, stacktwo, stackthree, stackfour, stackfive, stacksix);
                num1.setText(" " + new Random().nextInt(1, 15));
                coins[0] = Integer.parseInt(num1.getText().trim());
                num2.setText(" " + new Random().nextInt(1, 15));
                coins[1] = Integer.parseInt(num2.getText().trim());
                num3.setText(" " + new Random().nextInt(1, 15));
                coins[2] = Integer.parseInt(num3.getText().trim());
                num4.setText(" " + new Random().nextInt(1, 15));
                coins[3] = Integer.parseInt(num4.getText().trim());
                num5.setText(" " + new Random().nextInt(1, 15));
                coins[4] = Integer.parseInt(num5.getText().trim());
                num6.setText(" " + new Random().nextInt(1, 15));
                coins[5] = Integer.parseInt(num6.getText().trim());
                pane.getChildren().add(numbs);

            }
        });
        Table.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {

                for (int i = 0; i < 6; i++)
                    game[i][i] = coins[i];
                for (int gap = 2; gap <= 6; ++gap) {
                    for (int i = 0; i < 6 - gap + 1; ++i) {
                        int j = i + gap - 1;
                        if (j == i + 1) {
                            game[i][j] = Math.max(coins[i], coins[j]);
                        } else {
                            game[i][j] = Math.max(coins[i] + Math.min(game[i + 1][j - 1], game[i + 2][j]), coins[j] + Math.min(game[i][j - 2], game[i + 1][j - 1]));
                        }
                    }
                }
                Pane root2 = new Pane();
                Scene scenetwo = new Scene(root2, 1000, 750);
                root2.setBackground(Background.fill(Color.LAVENDER));
                Stage tablestage = new Stage();
                tablestage.setTitle("Coin Greed!");
                Image icon = new Image("file:coin.png");
                tablestage.getIcons().add(icon);
                tablestage.setScene(scenetwo);
                tablestage.show();
                int[][] indtable = what_index(coins, game);
                print(game, coins, indtable, root2);


            }
        });
        result.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                pane.getChildren().removeAll(dt, data);
                int[][] game = new int[6][6];
                for (int i = 0; i < 6; i++)
                    game[i][i] = coins[i];
                for (int gap = 2; gap <= 6; ++gap) {
                    for (int i = 0; i < 6 - gap + 1; ++i) {
                        int j = i + gap - 1;
                        if (j == i + 1) {
                            game[i][j] = Math.max(coins[i], coins[j]);
                        } else {
                            game[i][j] = Math.max(coins[i] + Math.min(game[i + 1][j - 1], game[i + 2][j]), coins[j] + Math.min(game[i][j - 2], game[i + 1][j - 1]));
                        }
                    }
                }
                int Max = 0;
                for (int n = 0; n < 6; n++) {
                    for (int k = 0; k < 6; k++) {
                        if (game[n][k] > Max) {
                            Max = game[n][k];
                        }
                    }
                }
                res.setText("" + Max);
                res.setFont(Font.font("Verdana", FontWeight.BOLD, 100));
                res.setFill(Color.PURPLE);
                res.setEffect(glow);
                answer.setTranslateX(500);
                answer.setTranslateY(200);
                mediaPlayer.play();
                answer.getChildren().addAll(mediaView, res);
                pane.getChildren().add(answer);
            }


        });
        how.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                Stage simu = new Stage();
                Pane root2 = new Pane();
                root2.setBackground(Background.fill(Color.LAVENDER));
                Scene scene2 = new Scene(root2, 800, 750);
                simu.setScene(scene2);
                simu.show();
                HBox coinsim = new HBox();
                coinsim.setTranslateX(100);
                coinsim.setTranslateY(230);
                root2.getChildren().addAll(coinsim);
                int[][] indtable = what_index(coins, game);
                int[] index = ChoosenNumb(indtable, coins);
                Circle[] Circles = new Circle[coins.length];
                StackPane[] Coin_stackPane = new StackPane[coins.length];
                Label[] arr_lable = new Label[coins.length];
                for (int i = 0; i < coins.length; i++) {
                    Coin_stackPane[i] = new StackPane();
                    Circles[i] = new Circle();
                    arr_lable[i] = new Label(String.valueOf(coins[i]));
                    Circles[i].setRadius(50);
                    Circles[i].setFill(Color.SILVER);
                    Circles[i].setStroke(Color.WHITE);
                    arr_lable[i].setFont(new Font("Veranda", 60));
                    arr_lable[i].setTextFill(Color.PURPLE);
                    Coin_stackPane[i].getChildren().addAll(Circles[i], arr_lable[i]);
                }
                for (int i = 0; i < Coin_stackPane.length; i++)
                    coinsim.getChildren().addAll(Coin_stackPane[i]);
                TranslateTransition[] translate = new TranslateTransition[index.length];
                PauseTransition pt = new PauseTransition(Duration.seconds(1));
                SequentialTransition sq = new SequentialTransition();
                sq.getChildren().add(pt);
                int opponent_resuilt = 0;
                for (int i = 0; i < index.length; i++) {
                    translate[i] = new TranslateTransition();
                    translate[i].setDuration(Duration.seconds(1));
                    translate[i].setNode(Coin_stackPane[index[i]]);
                    if (i % 2 == 0)
                        translate[i].setByY(-70);
                    else {
                        translate[i].setByY(+70);
                        opponent_resuilt = opponent_resuilt + coins[index[i]];
                    }
                    sq.getChildren().add(translate[i]);
                }

                sq.play();


            }
        });


        stage.setScene(sceneone);
        stage.show();

    }
}